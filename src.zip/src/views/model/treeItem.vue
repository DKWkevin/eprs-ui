<template>
<div></div>
</template>

<script>
export default {
  name: 'treeItem'
}
</script>

<style scoped>

</style>
