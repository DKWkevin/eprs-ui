<template>
  <div>
  <img src="@/assets/logo.png">
  <el-form :model="loginForm" :rules="fieldRules" ref="loginForm" label-position="left" label-width="0px" class="demo-ruleForm login-container">
    <span class="tool-bar">
    </span>
    <h2 class="title" style="padding-left:22px;" >系统登录</h2>
    <el-form-item prop="account">
      <el-input type="text" v-model="loginForm.account" auto-complete="off" placeholder="账号"></el-input>
    </el-form-item>
    <el-form-item prop="password">
      <el-input type="password" v-model="loginForm.password" auto-complete="off" placeholder="密码"></el-input>
    </el-form-item>
    <el-form-item >
      <el-col :span="12" style="height:40px">
        <el-form-item prop="captcha">
          <el-input type="test" v-model="loginForm.captcha" auto-complete="off" placeholder="验证码, 单击图片刷新"
            style="width: 100%;">
          </el-input>
        </el-form-item>
      </el-col>
      <el-col class="line" :span="1">&nbsp;</el-col>
      <el-col :span="11" style="height:40px">
        <el-form-item>
            <img style="width: 100%;" class="pointer" :src="loginForm.src" @click="refreshCaptcha">
        </el-form-item>
      </el-col>
    </el-form-item>
    <el-form-item >
      <el-col :span="11">
        <el-checkbox v-model="saveAll" label="记住密码"></el-checkbox>
      </el-col>
    </el-form-item>
    <el-form-item style="width:100%;">
      <el-button type="primary" style="width:48%;" @click.native.prevent="reset">重 置</el-button>
      <el-button type="primary" style="width:48%;" @click.native.prevent="login" :loading="loading">登 录</el-button>
    </el-form-item>
  </el-form>
  </div>
</template>

<script>
import Cookies from "js-cookie"
export default {
  name: 'Login',
  data() {
    return {
      loading: false,
      loginForm: {
        account: '',
        password: '',
        captcha:'',
        src: ''
      },
      fieldRules: {
        account: [
          { required: true, message: '请输入账号', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ]
      },
      checked: true,
      saveAll:false
    }
  },
  methods: {
    login() {
     /* Cookies.set("token","1");
      console.log("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJkYmEiLCJleHAiOjE1OTI1NzY2NDksImNyZWF0ZWQiOjE1OTI1MzM0NDk1MDUsImF1dGhvcml0aWVzIjpbeyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OmJnemN4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpzY2Joamg6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6cm9sZTpzdWJtaXQifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnRleGNlcHRpb246ZHhiaHljOnNlbGVjdGR0bCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpneGJobWw6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6ZW1wOmxpY2Vuc2UifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmxpY2Vuc2UifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6Y29tZmlybSJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGU6YXAifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmVkaXQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpjbnNrY3g6ZHRsIn0seyJhdXRob3JpdHkiOiJzeXM6cm9sZTp2aWV3In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Omp4YmhwY2N4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5Ijoic3lzOmVtcDphZGQifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZWdpb246ZHF0amZ6OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpwY2dsOmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnlzazpzZWxlY3QifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDp5c2s6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50ZXhjZXB0aW9uOmR4Ymh5YzpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6c2NkZGh0OmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejphZGQ6Y2FzaGllciJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpkd2pieHhnbDphZGQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDp4c3NrOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlZ2lvbjprY3RqZHFzaDp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6d2hzcGJoc3hwZjpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6ZHdqYnh4Z2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OnNjZGRodDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6ZGVsZXRlIn0seyJhdXRob3JpdHkiOiJxdWFsaXR5Omd5c2dsOnVwZGF0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpjZ3Fkd2g6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OmludmFsaWQifSx7ImF1dGhvcml0eSI6InN5czptZW51OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpqeGJocGNjeDp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6bWVudTphZGQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6YWRkOmJ1c2luZXNzIn0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OnVwZGF0ZXVzZXN0YXR1cyJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejphZGQifSx7ImF1dGhvcml0eSI6InN5czplbXA6ZWRpdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDp5d3lkeXd4aDpzZWxlY3QifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6dXBkYXRlOmJ1c2luZXNzIn0seyJhdXRob3JpdHkiOiJyZWdpb246ZHF0amZ6OmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6amhteGN4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpneXNnbDphZGQifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6aHBqYnh4OnVwZGF0ZSJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpraGdsOnVwZGF0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOm1lbnU6dmlldyJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpxeXR4bDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmFkZCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpneXN0aHh4d2g6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Omd5c3RoeHh3aDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6aHBqYnh4OmFkZCJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpocGpieHg6c2VsZWN0In0seyJhdXRob3JpdHkiOiJxdWFsaXR5OmtoZ2w6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Ondoc3BiaHN4bHM6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OmNvbmZpcm0ifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6Z3lzZ2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJxdWFsaXR5OmtoZ2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OnNjYmh5Y2psOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNuc2tjeDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6ZHdqYnh4Z2w6dXBkYXRlIn0seyJhdXRob3JpdHkiOiJyZWdpb246a2N0amRxc2g6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6ZW1wOnZpZXcifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpjZGZrOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpqaGRjeDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmRlbGV0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOnJvbGU6cm9sZWRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNkZms6YWRkIn0seyJhdXRob3JpdHkiOiJyZWdpb246a2N0amRxc2g6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6cGZ5c3BqYmN6OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOm1lbnU6ZWRpdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGU6Y2FzaGllciJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNuc2tjeDp1cGRhdGVhcnJwcmVjZHRsIn1dfQ.nH9YbuTS8M57IR3K8xMNbaP3UF-__B2iPOhekXbR63LeWQhEYiWHOUhYCuF61bwwp9fAEtcEIOD6ewZiRWgWww");
      console.log("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJkYmEiLCJleHAiOjE1OTI1NzY2NDksImNyZWF0ZWQiOjE1OTI1MzM0NDk1MDUsImF1dGhvcml0aWVzIjpbeyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OmJnemN4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpzY2Joamg6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6cm9sZTpzdWJtaXQifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnRleGNlcHRpb246ZHhiaHljOnNlbGVjdGR0bCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpneGJobWw6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6ZW1wOmxpY2Vuc2UifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmxpY2Vuc2UifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6Y29tZmlybSJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGU6YXAifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmVkaXQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpjbnNrY3g6ZHRsIn0seyJhdXRob3JpdHkiOiJzeXM6cm9sZTp2aWV3In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Omp4YmhwY2N4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5Ijoic3lzOmVtcDphZGQifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZWdpb246ZHF0amZ6OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpwY2dsOmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnlzazpzZWxlY3QifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDp5c2s6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50ZXhjZXB0aW9uOmR4Ymh5YzpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6c2NkZGh0OmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejphZGQ6Y2FzaGllciJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpkd2pieHhnbDphZGQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDp4c3NrOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlZ2lvbjprY3RqZHFzaDp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6d2hzcGJoc3hwZjpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6ZHdqYnh4Z2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OnNjZGRodDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6ZGVsZXRlIn0seyJhdXRob3JpdHkiOiJxdWFsaXR5Omd5c2dsOnVwZGF0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpjZ3Fkd2g6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OmludmFsaWQifSx7ImF1dGhvcml0eSI6InN5czptZW51OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpqeGJocGNjeDp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6bWVudTphZGQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6YWRkOmJ1c2luZXNzIn0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OnVwZGF0ZXVzZXN0YXR1cyJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejphZGQifSx7ImF1dGhvcml0eSI6InN5czplbXA6ZWRpdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDp5d3lkeXd4aDpzZWxlY3QifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6dXBkYXRlOmJ1c2luZXNzIn0seyJhdXRob3JpdHkiOiJyZWdpb246ZHF0amZ6OmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6amhteGN4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpneXNnbDphZGQifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6aHBqYnh4OnVwZGF0ZSJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpraGdsOnVwZGF0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOm1lbnU6dmlldyJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpxeXR4bDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmFkZCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpneXN0aHh4d2g6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Omd5c3RoeHh3aDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6aHBqYnh4OmFkZCJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpocGpieHg6c2VsZWN0In0seyJhdXRob3JpdHkiOiJxdWFsaXR5OmtoZ2w6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Ondoc3BiaHN4bHM6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OmNvbmZpcm0ifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6Z3lzZ2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJxdWFsaXR5OmtoZ2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OnNjYmh5Y2psOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNuc2tjeDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6ZHdqYnh4Z2w6dXBkYXRlIn0seyJhdXRob3JpdHkiOiJyZWdpb246a2N0amRxc2g6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6ZW1wOnZpZXcifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpjZGZrOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpqaGRjeDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmRlbGV0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOnJvbGU6cm9sZWRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNkZms6YWRkIn0seyJhdXRob3JpdHkiOiJyZWdpb246a2N0amRxc2g6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6cGZ5c3BqYmN6OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOm1lbnU6ZWRpdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGU6Y2FzaGllciJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNuc2tjeDp1cGRhdGVhcnJwcmVjZHRsIn1dfQ.nH9YbuTS8M57IR3K8xMNbaP3UF-__B2iPOhekXbR63LeWQhEYiWHOUhYCuF61bwwp9fAEtcEIOD6ewZiRWgWww".length)
      Cookies.set("token1","eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJkYmEiLCJleHAiOjE1OTI1NzY2NDksImNyZWF0ZWQiOjE1OTI1MzM0NDk1MDUsImF1dGhvcml0aWVzIjpbeyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OmJnemN4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpzY2Joamg6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6cm9sZTpzdWJtaXQifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnRleGNlcHRpb246ZHhiaHljOnNlbGVjdGR0bCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpneGJobWw6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6ZW1wOmxpY2Vuc2UifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmxpY2Vuc2UifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6Y29tZmlybSJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGU6YXAifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmVkaXQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpjbnNrY3g6ZHRsIn0seyJhdXRob3JpdHkiOiJzeXM6cm9sZTp2aWV3In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Omp4YmhwY2N4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5Ijoic3lzOmVtcDphZGQifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZWdpb246ZHF0amZ6OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpwY2dsOmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnlzazpzZWxlY3QifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDp5c2s6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50ZXhjZXB0aW9uOmR4Ymh5YzpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6c2NkZGh0OmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejphZGQ6Y2FzaGllciJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpkd2pieHhnbDphZGQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDp4c3NrOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlZ2lvbjprY3RqZHFzaDp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6d2hzcGJoc3hwZjpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6ZHdqYnh4Z2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OnNjZGRodDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6ZGVsZXRlIn0seyJhdXRob3JpdHkiOiJxdWFsaXR5Omd5c2dsOnVwZGF0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpjZ3Fkd2g6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OmludmFsaWQifSx7ImF1dGhvcml0eSI6InN5czptZW51OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpqeGJocGNjeDp1cGRhdGUifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6eXdza2M6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6bWVudTphZGQifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6YWRkOmJ1c2luZXNzIn0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OnVwZGF0ZXVzZXN0YXR1cyJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejphZGQifSx7ImF1dGhvcml0eSI6InN5czplbXA6ZWRpdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDp5d3lkeXd4aDpzZWxlY3QifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpwZnlzcGpiY3o6dXBkYXRlOmJ1c2luZXNzIn0seyJhdXRob3JpdHkiOiJyZWdpb246ZHF0amZ6OmFkZCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejpzZWxlY3QifSx7ImF1dGhvcml0eSI6InJlcGxlbmlzaG1lbnQ6amhteGN4OnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpneXNnbDphZGQifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6aHBqYnh4OnVwZGF0ZSJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpraGdsOnVwZGF0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOm1lbnU6dmlldyJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpxeXR4bDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmFkZCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpneXN0aHh4d2g6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Omd5c3RoeHh3aDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6aHBqYnh4OmFkZCJ9LHsiYXV0aG9yaXR5IjoicXVhbGl0eTpocGpieHg6c2VsZWN0In0seyJhdXRob3JpdHkiOiJxdWFsaXR5OmtoZ2w6YWRkIn0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50Ondoc3BiaHN4bHM6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6Y25za2N4OmNvbmZpcm0ifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6Z3lzZ2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJxdWFsaXR5OmtoZ2w6c2VsZWN0In0seyJhdXRob3JpdHkiOiJyZXBsZW5pc2htZW50OnNjYmh5Y2psOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNuc2tjeDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InF1YWxpdHk6ZHdqYnh4Z2w6dXBkYXRlIn0seyJhdXRob3JpdHkiOiJyZWdpb246a2N0amRxc2g6YWRkIn0seyJhdXRob3JpdHkiOiJzeXM6ZW1wOnZpZXcifSx7ImF1dGhvcml0eSI6ImZpbmFuY2lhbDpjZGZrOnNlbGVjdCJ9LHsiYXV0aG9yaXR5IjoicmVwbGVuaXNobWVudDpqaGRjeDpzZWxlY3QifSx7ImF1dGhvcml0eSI6InN5czpyb2xlOmRlbGV0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOnJvbGU6cm9sZWRlbGV0ZSJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNkZms6YWRkIn0seyJhdXRob3JpdHkiOiJyZWdpb246a2N0amRxc2g6c2VsZWN0In0seyJhdXRob3JpdHkiOiJmaW5hbmNpYWw6cGZ5c3BqYmN6OmRlbGV0ZSJ9LHsiYXV0aG9yaXR5Ijoic3lzOm1lbnU6ZWRpdCJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOnBmeXNwamJjejp1cGRhdGU6Y2FzaGllciJ9LHsiYXV0aG9yaXR5IjoiZmluYW5jaWFsOmNuc2tjeDp1cGRhdGVhcnJwcmVjZHRsIn1dfQ.nH9YbuTS8M57IR3K8xMNbaP3UF-__B2iPOhekXbR63LeWQhEYiWHOUhYCuF61bwwp9fAEtcEIOD6ewZiRWgWww");
     */
     this.loading = true;
      let userInfo = { account:this.loginForm.account, password:this.loginForm.password,
        captcha:this.loginForm.captcha };
      this.$api.login.login(userInfo).then((res) => {  // 调用登录接口
          if(res.msg != null) {
            this.$message({ message: res.msg, type: 'error' });
            this.refreshCaptcha();
            this.loading = false;
          } else {
            //Cookies.set('token', res.data.token);
            // 保存用户到本地会话
            if(this.saveAll===true){
              this.addCookies('account', this.loginForm.account);
              this.addCookies('password', this.loginForm.password);
              this.addCookies('saveAll', this.saveAll);
            }else{
              if(Cookies.get('account')!==undefined){
                Cookies.remove('account');
              }
              if(Cookies.get('password')!==undefined){
                Cookies.remove('password');
              }
              if(Cookies.get('saveAll')!==undefined){
                Cookies.remove('saveAll');
              }
            }
            sessionStorage.setItem('token', res.data.token); // token
            sessionStorage.setItem('userid', res.data.user.employeeid); // 人员id
            sessionStorage.setItem('username', res.data.user.employeename); // 人员名称
            sessionStorage.setItem('useropcode', res.data.user.employeeopcode); // 人员操作码
            sessionStorage.setItem('deptid', res.data.user.deptid); // 部门id
            sessionStorage.setItem('deptname', res.data.user.deptname); // 部门名称
            sessionStorage.setItem('companyid', res.data.user.companyid); // 公司id
            sessionStorage.setItem('companyname',res.data.user.companyname);//公司名称
            this.$store.commit('menuRouteLoaded', false); // 要求重新加载导航菜单
            this.$router.push('/');  // 登录成功，跳转到主页
          }
          this.loading = false
        }).catch((res) => {
          this.$message({ message: res.message, type: 'error' });
          this.refreshCaptcha();
          this.loading = false;
        })
    },
    refreshCaptcha: function(){
      this.loginForm.src = this.global.baseUrl + "/captcha.jpg?t=" + new Date().getTime();
    },
    reset() {
      this.$refs.loginForm.resetFields();
    },
    addCookies(name,value){
      let str=name+"="+value+"; expires=Fri, 31 Dec 9999 23:59:59 GMT";
      document.cookie = str;
    }
  },
  created(){
    if(Cookies.get('account')!==undefined){
      this.loginForm.account=Cookies.get('account');
    }
    if(Cookies.get('password')!==undefined){
      this.loginForm.password=Cookies.get('password');
    }
    if(Cookies.get('saveAll')!==undefined){
      this.saveAll = Cookies.get('saveAll') === "true";
    }
  },
  mounted() {
    this.refreshCaptcha();
  }
}
</script>

<style lang="scss" scoped>
  .login-container {
    -webkit-border-radius: 5px;
    border-radius: 5px;
    -moz-border-radius: 5px;
    background-clip: padding-box;
    margin: 100px auto;
    width: 350px;
    padding: 35px 35px 15px 35px;
    background: #fff;
    border: 1px solid #eaeaea;
    box-shadow: 0 0 25px #cac6c6;
    .title {
      margin: 0px auto 30px auto;
      text-align: center;
      color: #505458;
    }
  }
</style>
