<template>
<div>
<!--<el-form label-width="65px" label-position="right">
    <el-form-item label="SQL">
      <el-input
        type="textarea"
        v-model="sql"
        :autosize="{minRows:2}"
        placeholder="请输入内容"
      ></el-input>
      <el-form-item>
        <el-button type="primary" small round>下一步</el-button>
      </el-form-item>
    </el-form-item>
  </el-form>-->
  <tree-menu :treeData="treeData"></tree-menu>
</div>
</template>

<script>
import treeMenu from './model/treeMenu'
export default {
  name: 'Test',
  components:{treeMenu},
  data(){
    return {
      //sql:''
      treeData:[{value:1,label:'1', children:[]}]
    }
  }
}
</script>

<style scoped>

</style>
