<template>
<div>
  <e-query
    ref="query"
    :form-data="formData"
    :form-list="formList"
    :label-width="formLabelWidth"
    :collapseStatus="collapseStatus"
    :btn-options="btnOptions"
    @openHov="queryHov"
    @query="queryFunction"
  ></e-query>
  <e-table
    ref="doctable"
    :loading="loading"
    :table-columns="tableColumns"
    :table-data="tableData"
    :table-height="tableHeight"
    @handle="handleQuery"
    @currentChange="handleChange"
    @sizeChange="handleChange"
  ></e-table>
  <hpjcsjwh-dtl
    v-if="hpjcsjwhVisible"
    :dtlStatus="dtlStatus"
    :dtlData="dtlData"
    :drugtypeOptions="drugtypeOptions"
    :usestatusOptions="usestatusOptions"
    :storageConditionOptions="storageConditionOptions"
    :transConditionOptions="transConditionOptions"
    :drugadminClassOptions="drugadminClassOptions"
    :brandGradeOptions="brandGradeOptions"
    :informationClassOptions="informationClassOptions"
    :class1Options="class1Options"
    :classAOptions="classAOptions"
    :companyTypeOptions="companyTypeOptions"
    :unitTypeOptions="unitTypeOptions"
    :bzuseStatusOptions="bzuseStatusOptions"
    :docTitle="docTitle"
  ></hpjcsjwh-dtl>
  <hov-tools v-if="queryGoodsVisible" :hov-data="queryGoodsHov"></hov-tools>
  <hov-tools v-if="queryFactVisible" :hov-data="queryFactHov" :label-width="factLabelWidth"></hov-tools>
</div>
</template>

<script>
//货品基础数据维护
import EQuery from "@/views/Core/EQuery";
import HovTools from "@/views/Core/HovTools";
import ETable from "@/views/Core/ETable";
import HpjcsjwhDtl from "@/views/Function/Quality/HpjcsjwhDtl";
import {exportExcelDOM, formDataReset, paramsFormat, selectDdlOption, selectOption} from "@/utils/functions";
export default {
  name: 'Hpjcsjwh',
  components:{HpjcsjwhDtl, ETable, HovTools, EQuery},
  data(){
    return {
      formList:[
        {type:'inputHov',id:'goodsid',label:'货品ID',formWidth:180,labelWidth:65},
        {type:'input',id:'goodsname',label:'货品名称'},
        {type:'inputHov',id:'factid',label:'生产企业',disabled:true,formWidth:180,labelWidth:65},
        {type:'input',id:'factname',label:'生产企业名称',disabled:true},
        {type:'select',id:'usestatus',label:'状态',options:[],clearable:true},
        {type:'input',id:'gbcode',label:'批准文号'},
        {type:'select',id:'drugadminclass',label:'药监分类',options:[],clearable:true},
        {type:'select',id:'informationclass',label:'资料类别',options:[],clearable:true},
        {type:'input',id:'shflbm',label:'税收分类编码'},
        {type:'check',id:'sflcpz',label:'是否冷藏品种',trueLabel:'1',falseLabel:null}
      ],
      formData:{goodsid:null,goodsname:null,factid:null,factname:null,usestatus:null,gbcode:null,drugadminclass:null,informationclass:null,shflbm:null,sflcpz:false},
      formLabelWidth:'100px',
      collapseStatus:true,
      btnOptions:[
        {id:'query',icon:"fa fa-search", label:"action.search",perms:"quality:hpjbxx:select"},
        {id:'add',icon:"fa fa-plus", label:"action.add",perms:"quality:hpjbxx:add"},
        {id:'reset',icon:"fa fa-cog", label:"action.reset",perms:"quality:hpjbxx:select"},
        {id:'download',icon:"fa fa-download", label:"action.download",perms:"quality:hpjbxx:select"}
      ],
      queryGoodsVisible:false,
      queryGoodsHov:{
        hovTitle:'货品查询',
        hovUrl: "goodsidhov/select",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'queryGoodsVisible',
        hovColumns:
          [
            {id: "goodsid", name: "货品ID",queryStatus:true,dataStatus:2,fillid:"goodsid"},
            {id: "goodsname", name: "货品名称",queryStatus:true,dataStatus:1,fillid:"goodsname"},
            {id: "opcode", name: "货品操作码",queryStatus:true,dataStatus:1}
          ]
      },
      queryFactVisible:false,
      factLabelWidth:'110',
      queryFactHov:{
        hovTitle:'生产企业查询',
        hovUrl: "companyidhov/selectcompanyid",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'queryFactVisible',
        hovColumns:
          [
            {id: "companyid", name: "生产企业ID",queryStatus:true,dataStatus:2,fillid:"factid"},
            {id: "companyname", name: "生产企业名称",queryStatus:true,dataStatus:1,fillid:"factname"},
            {id: "companyopcode", name: "生产企业操作码",queryStatus:true,dataStatus:1}
          ]
      },
      tableHeight:300,
      tableColumns:[
        {prop:'goodsid',label:'货品ID',type:0,tableStatus:0,sortable:true,width:90,widthStatus:true},
        {prop:'opcode',label:'操作码',type:0,tableStatus:0,width:100,widthStatus:true},
        {prop:'goodsname',label:'名称',type:0,tableStatus:0,width:200,widthStatus:true},
        {prop:'goodstype',label:'货品规格',type:0,tableStatus:0,width:100,widthStatus:true},
        {prop:'prodarea',label:'产地',type:0,tableStatus:0},
        {prop:'usestatusname',label:'状态',type:0,tableStatus:0},
        {prop:'gbcode',label:'批准文号',type:0,tableStatus:0,width:100,widthStatus:true},
        {prop:'factid',label:'生产企业ID',type:0,tableStatus:0,sortable:true,width:110,widthStatus:true},
        {prop:'fact_companyname',label:'生产企业名称',type:0,tableStatus:0,width:150,widthStatus:true},
        {prop:'goodsno',label:'编码',type:0,tableStatus:0,width:70,widthStatus:true},
        {prop:'goodstag',label:'货品标记',type:0,tableStatus:0,width:70,widthStatus:true},
        {prop:'goodsshortname',label:'简称',type:0,tableStatus:0,width:70,widthStatus:true},
        {prop:'goodsformalname',label:'商品名',type:0,tableStatus:0,width:90,widthStatus:true},
        {prop:'goodsformalpinyin',label:'通用名拼音',type:0,tableStatus:0,width:90,widthStatus:true},
        {prop:'goodsunit',label:'货品基本单位',type:0,tableStatus:0},
        {prop:'defaultpack',label:'缺省包装',type:0,tableStatus:0},
        {prop:'credate',label:'建立日期',type:2,tableStatus:0,width:150,widthStatus:true},
        {prop:'inputmanid',label:'创建人',type:0,tableStatus:0},
        {prop:'inputmanname',label:'创建人名称',type:0,tableStatus:0},
        {prop:'usestatus',label:'状态ID',type:0,tableStatus:0,sortable:true,width:90,widthStatus:true},
        {prop:'standardcode',label:'质量标准码',type:0,tableStatus:0},
        {prop:'ssxkcyr',label:'上市许可持有人',type:0,tableStatus:0},
        {prop:'commissionid',label:'委托加工企业ID',type:0,tableStatus:0},
        {prop:'com_companyname',label:'委托加工企业名称',type:0,tableStatus:0},
        {prop:'salestaxrate',label:'销售税率',type:0,tableStatus:0},
        {prop:'sutaxrate',label:'进货税率',type:0,tableStatus:0},
        {prop:'jybf',label:'简易办法',type:0,tableStatus:0},
        {prop:'drugtype',label:'剂型',type:0,tableStatus:0},
        {prop:'memo',label:'备注',type:0,tableStatus:0},
        {prop:'ifimport',label:'库存保障品种',type:0,tableStatus:0},
        {prop:'ifback',label:'是否可退货',type:0,tableStatus:0},
        {prop:'iforder',label:'订单商品',type:0,tableStatus:0},
        {prop:'ifctrlzb',label:'是否控制中包',type:0,tableStatus:0},
        {prop:'qua_goodsid',label:'货品标识号',type:0,tableStatus:0},
        {prop:'qualityscopeid',label:'所属经营范围',type:0,tableStatus:0},
        {prop:'scopename',label:'所属经营范围名称',type:0,tableStatus:0},
        {prop:'validperiod',label:'效期',type:0,tableStatus:0},
        {prop:'periodunit',label:'期间单位',type:0,tableStatus:0},
        {prop:'storagecondition',label:'仓储条件ID',type:0,tableStatus:0},
        {prop:'storageconditionname',label:'仓储条件',type:0,tableStatus:0},
        {prop:'transcondition',label:'运输条件ID',type:0,tableStatus:0},
        {prop:'transconditionname',label:'运输条件',type:0,tableStatus:0},
        {prop:'functionlist',label:'功能主治',type:0,tableStatus:0},
        {prop:'usage',label:'用法用量',type:0,tableStatus:0},
        {prop:'packstandard',label:'包装是否合格',type:0,tableStatus:0},
        {prop:'forcetypeno',label:'国家强制产品认证',type:0,tableStatus:0},
        {prop:'productapprovno',label:'产品说明书批件',type:0,tableStatus:0},
        {prop:'apparatusno',label:'计量器具许可证号',type:0,tableStatus:0},
        {prop:'apparatusperiod',label:'计量器具许可证效期',type:0,tableStatus:0},
        {prop:'otherperiod',label:'其他关键质量信息中效期',type:0,tableStatus:0},
        {prop:'drugadminclass',label:'药监分类ID',type:0,tableStatus:0},
        {prop:'drugadminclassname',label:'药监分类',type:0,tableStatus:0},
        {prop:'medicatype',label:'中/西药',type:0,tableStatus:0},
        {prop:'brand',label:'品牌',type:0,tableStatus:0},
        {prop:'brandgrade',label:'品牌等级',type:0,tableStatus:0},
        {prop:'brandgradename',label:'品牌等级',type:0,tableStatus:0},
        {prop:'markettime',label:'上市时间',type:2,tableStatus:0,width:150,widthStatus:true},
        {prop:'adflag',label:'广告品种',type:0,tableStatus:0},
        {prop:'clinicalflag',label:'临床品种',type:0,tableStatus:0},
        {prop:'drugsflag',label:'药品非药品',type:0,tableStatus:0},
        {prop:'approveno',label:'生产批文号',type:0,tableStatus:0},
        {prop:'approveperiod',label:'生产批文效期',type:0,tableStatus:0},
        {prop:'qualitystandardno',label:'质量标准编号',type:0,tableStatus:0},
        {prop:'qualitystandardperiod',label:'质量标准效期',type:0,tableStatus:0},
        {prop:'inspectionno',label:'检验报告单编号',type:0,tableStatus:0},
        {prop:'inspectionperiod',label:'检验报告单效期',type:0,tableStatus:0},
        {prop:'sampleflag',label:'样品',type:0,tableStatus:0},
        {prop:'trademark',label:'注册商标',type:0,tableStatus:0},
        {prop:'trademarkno',label:'商标注册证号',type:0,tableStatus:0},
        {prop:'trademarkperiod',label:'商标注册证效期',type:0,tableStatus:0},
        {prop:'barcodeno',label:'商品条码证',type:0,tableStatus:0},
        {prop:'barcodeperiod',label:'商品条码效期',type:0,tableStatus:0},
        {prop:'bailername',label:'委托书姓名',type:0,tableStatus:0},
        {prop:'baileridcard',label:'委托书身份证',type:0,tableStatus:0},
        {prop:'bailerperiod',label:'委托书效期',type:0,tableStatus:0},
        {prop:'commissproduceno',label:'药品委托生产批件编号',type:0,tableStatus:0},
        {prop:'commissproduceperiod',label:'药品委托生产批件效期',type:0,tableStatus:0},
        {prop:'specialgoodsno',label:'特殊商品卫生许可证号',type:0,tableStatus:0},
        {prop:'specialgoodsperiod',label:'特殊商品卫生证效期',type:0,tableStatus:0},
        {prop:'informationclass',label:'资料类别',type:0,tableStatus:0},
        {prop:'informationclassname',label:'资料类别',type:0,tableStatus:0},
        {prop:'compound',label:'单方复方药',type:0,tableStatus:0},
        {prop:'ccode',label:'药品本位码',type:0,tableStatus:0},
        {prop:'goodsid_cgjl',label:'货品ID',type:0,tableStatus:0},
        {prop:'managerid',label:'采购经理ID',type:0,tableStatus:0},
        {prop:'managername',label:'采购经理',type:0,tableStatus:0},
        {prop:'class1',label:'采购分组分类1',type:0,tableStatus:0},
        {prop:'class1name',label:'采购分组分类1',type:0,tableStatus:0},
        {prop:'class2',label:'采购分组分类2',type:0,tableStatus:0},
        {prop:'companyid',label:'合作伙伴ID',type:0,tableStatus:0},
        {prop:'companyname',label:'合作伙伴',type:0,tableStatus:0},
        {prop:'classa',label:'A类分类',type:0,tableStatus:0},
        {prop:'classaname',label:'A类分类',type:0,tableStatus:0},
        {prop:'property',label:'品牌名称属性',type:0,tableStatus:0},
        {prop:'companytype',label:'合作伙伴类型',type:0,tableStatus:0},
        {prop:'companytypename',label:'合作伙伴类型',type:0,tableStatus:0},
        {prop:'cwspflbm',label:'财务商品分类编码',type:0,tableStatus:0},
        {prop:'caozuo',label:'操作',fixed:'right',type:1,width:100,widthStatus:true,tableStatus:0,options:[
            {id:'add',icon:"fa fa-edit", label:"action.edit",perms:"quality:hpjbxx:update"}
          ]},
      ],
      tableData:[],
      loading:false,
      hpjcsjwhVisible:false,
      dtlStatus:false,
      dtlData:{},
      drugtypeOptions:[],
      usestatusOptions:[],
      storageConditionOptions:[],
      transConditionOptions:[],
      drugadminClassOptions:[],
      brandGradeOptions:[],
      informationClassOptions:[],
      class1Options:[],
      classAOptions:[],
      companyTypeOptions:[],
      unitTypeOptions:[],
      bzuseStatusOptions:[],
      docTitle:''
    }
  },
  created(){
    this.tableHeight=(window.innerHeight-240);
    selectOption(this.formList,'usestatus',selectDdlOption('GOODS_USESTATUS'));
    selectOption(this.formList,'drugadminclass',selectDdlOption('GOODS_DRUGADMINCLASS'));
    selectOption(this.formList,'informationclass',selectDdlOption('GOODS_INFORMATIONCLASS'));
    this.drugtypeOptions=selectDdlOption('YPJX');
    this.usestatusOptions=selectDdlOption('GOODS_USESTATUS');
    this.storageConditionOptions=selectDdlOption('PUB_GOODS_STORECONDITION');
    this.transConditionOptions=selectDdlOption('PUB_GOODS_TRANSCONDITION');
    this.drugadminClassOptions=selectDdlOption('GOODS_DRUGADMINCLASS');
    this.brandGradeOptions=selectDdlOption('GOODS_BRANDGRADE');
    this.informationClassOptions=selectDdlOption('GOODS_INFORMATIONCLASS');
    this.$api.hpjcsjwh.selectCgfz({}).then(res => {
      if(res.code===200){
        res.data.forEach(e=>{
          let tel={};
          tel.value=e.groupid;
          tel.label = e.groupname;
          this.class1Options.push(tel);
        })
      }
    }).catch(error => {
      return false;
    });
    this.classAOptions=selectDdlOption('CG_CLASSA');
    this.companyTypeOptions=selectDdlOption('CG_COMPANYTYPE');
    this.unitTypeOptions=selectDdlOption('GOODS_UNITTYPE');
    this.bzuseStatusOptions=selectDdlOption('GOODS_UNIT_USESTATUS');
  },
  methods:{
    queryFunction(data){
      if(data==="query"){
        let pageSize=this.$refs.doctable.pageSize;
        this.selectDoc(1,pageSize);
      }else if(data === "add"){
        this.hpjcsjwhVisible=true;
        this.docTitle='新增货品基础数据维护';
        this.dtlStatus=false;
      }else if(data==="reset"){
        formDataReset(this.formData);
      }else if(data === "download"){
        exportExcelDOM(this.tableColumns,this.tableData,'货品基础数据维护');
      }
    },
    handleChange(data){
      this.selectDoc(data.pageNum,data.pageSize);
    },
    selectDoc(pageNum,pageSize){
      this.$refs.query.collapse=false;
      let formData=this.formData;
      let params=paramsFormat(formData);
      params.companyid=Number(sessionStorage['companyid']);
      this.tableData=[];
      this.loading=true;
      this.$api.hpjcsjwh.selectDoc({pageNum:pageNum,pageSize:pageSize,params:params}).then(res => {
        if (res.code === 200) {
          this.tableData = Object.freeze(res.data.content);
          this.$refs.doctable.pageSize = res.data.pageSize;
          this.$refs.doctable.currentPage = res.data.pageNum;
          this.$refs.doctable.total = res.data.totalSize;
          this.loading = false;
        }
      }).catch(error => {
        this.loading=false;
        return false;
      })
    },
    handleQuery(data){
      this.hpjcsjwhVisible=true;
      this.dtlStatus=true;
      this.docTitle='修改货品基础数据维护';
      this.dtlData=data.row;
    },
    queryHov(data){
      if(data === 'goodsid'){
        this.queryGoodsVisible = true;
      }else if(data === 'factid'){
        this.queryFactVisible = true;
      }
    }
  }
}
</script>
