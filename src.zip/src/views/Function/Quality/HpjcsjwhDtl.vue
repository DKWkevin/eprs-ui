<template>
<div class="hpjcsjwhdtl">
  <el-dialog :visible.sync="dialogVisible" :title="docTitle" :width="dialogWidth" :top="dialogTop" :destroy-on-close="true" @close="docClose" :close-on-click-modal="false">
    <el-tabs type="border-card" @tab-click="handleClick" v-model="activeTabs">
      <el-tab-pane label="货品基本信息" name="first">
        <el-form :model="base" ref="baseForm" :label-width="baseLabelWidth" :label-position="labelOptions" :rules="baseRules">
          <el-form-item v-if="dtlStatus===true" label="货品ID" style="width:440px;float:left;">
            <el-input v-model="goodsid" disabled="disabled"></el-input>
          </el-form-item>
          <el-form-item label="通用名称" style="width:440px;float:left;" prop="goodsname">
            <el-input v-model="base.goodsname" style="width:340px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="操作码" style="width:260px;float:left;" prop="opcode">
            <el-input v-model="base.opcode" style="width:160px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="通用名拼音" style="width:190px;float:left">
            <el-input v-model="base.goodsformalpinyin" style="width:140px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="商品名" style="width:440px;float:left;">
            <el-input v-model="base.goodsformalname" style="width:340px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="规格" style="width:260px;float:left" prop="goodstype">
            <el-input v-model="base.goodstype" style="width:160px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="货品标记" style="width:220px;float:left">
            <el-input v-model="base.goodstag"  style="width:120px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="剂型" style="width:210px;float:left">
            <el-select v-model="base.drugtype" style="width:120px;" clearable>
              <el-option v-for="item in drugtypeOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="基本单位" style="width:190px;float:left" prop="goodsunit">
            <el-input v-model="base.goodsunit" style="width:120px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="产地" style="width:280px;float:left" prop="prodarea">
            <el-input v-model="base.prodarea" style="width:180px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="缺省包装" style="width:220px;float:left">
            <el-input v-model="base.defaultpack" style="width:120px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="批准文号" style="clear:both;width:260px;float:left">
            <el-input v-model="base.gbcode" style="width:160px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="质量标准码" style="width:260px;float:left">
            <el-input v-model="base.standardcode" style="width:160px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="销售税率" style="width:160px;float:left" prop="salestaxrate">
            <el-select v-model="base.salestaxrate" style="width:80px;float:left;" clearable>
              <el-option :value="0.13" label="0.13"></el-option>
              <el-option :value="0.09" label="0.09"></el-option>
              <el-option :value="0" label="0"></el-option>
              <el-option :value="0.03" label="0.03"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="进货税率" style="width:160px;float:left">
            <el-select v-model="base.sutaxrate" style="width:80px;float:left;" clearable>
              <el-option :value="0.13" label="0.13"></el-option>
              <el-option :value="0.09" label="0.09"></el-option>
              <el-option :value="0" label="0"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="上市许可持有人" style="width:320px;float:left">
            <el-input v-model="base.zxcolumn4" style="width:160px;float:left;"></el-input>
            <el-button icon="el-icon-search" circle @click="openHov('zxcolumn4')"></el-button>
          </el-form-item>
          <el-form-item label="生产企业ID" style="width:240px;float:left" prop="factid">
            <el-input v-model="base.factid" style="width:80px;float:left;margin-right:3px;" disabled="disabled"></el-input>
            <el-button icon="el-icon-search" circle @click="openHov('factid')" style="float:left"></el-button>
          </el-form-item>
          <el-form-item label="生产企业" style="width:360px;float:left">
            <el-input v-model="base.factname" disabled="disabled" style="width:280px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="委托加工企业ID" style="clear:both;width:280px;float:left">
            <el-input v-model="base.commissionid" style="width:120px;float:left;margin-right:5px;" disabled="disabled"></el-input>
            <el-button icon="el-icon-search" circle @click="openHov('commissionid')"></el-button>
          </el-form-item>
          <el-form-item label="委托加工企业" style="width:300px;float:left">
            <el-input v-model="base.commissionname" disabled="disabled" style="width:220px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="编码" style="width:150px;float:left">
          <el-input v-model="base.goodsno" style="width:100px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="简称" style="width:190px;float:left">
            <el-input v-model="base.goodsshortname" style="width:120px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="税收分类编码" style="width:280px;float:left">
            <el-input v-model="base.zxcolumn3" style="width:170px;float:left;" @keypress="zx3Keypress($event)" @blur="zx3blur"></el-input>
          </el-form-item>
          <el-form-item label="税收分类名称" style="width:360px;float:left">
            <el-input v-model="base.shflmc" style="width:260px;float:left;" disabled="disabled"></el-input>
          </el-form-item>
          <el-form-item label="状态" style="width:180px;float:left">
           <el-select v-model="base.usestatus" style="width:120px;float:left;" clearable>
             <el-option v-for="item in usestatusOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
           </el-select>
         </el-form-item>
          <el-form-item label="备注" style="width:280px;float:left">
            <el-input v-model="base.memo" style="width:170px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="创建人" style="width:160px;float:left">
            <el-input v-model="base.inputmanid" disabled="disabled" style="width:70px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="创建人名称" style="width:180px;float:left">
            <el-input v-model="base.inputmanname" disabled="disabled" style="width:90px;float:left;"></el-input>
          </el-form-item>
          <el-form-item label="建立日期" style="width:220px;float:left">
            <el-date-picker v-model="base.credate" disabled="disabled" type="datetime" style="width:140px;"></el-date-picker>
          </el-form-item>
          <el-form-item id="checkGroup" style="float:left;margin-left:0;width:850px;">
              <el-checkbox v-model="base.jybf" label="1">简易办法</el-checkbox>
              <el-checkbox v-model="base.ifimport" label="1">库存保障品种</el-checkbox>
              <el-checkbox v-model="base.ifback" label="1">是否可退货</el-checkbox>
              <el-checkbox v-model="base.iforder" label="1" disabled="disabled">订单商品</el-checkbox>
              <el-checkbox v-model="base.ifctrlzb" label="1">是否控制中包</el-checkbox>
              <el-checkbox v-model="base.sflcpz" label="1">是否冷藏品种</el-checkbox>
              <el-checkbox v-model="base.sfyypz" label="1">是否医院品种</el-checkbox>
          </el-form-item>
          <el-form-item style="width:100%;clear:both;float:left">
            <el-button type="info" size="small" round @click="docClose">取消</el-button>
            <el-button type="primary" size="small" round @click="addBase">保存</el-button>
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="货品包装信息"  name="second">
        <el-form :label-width="bzLabelWidth" :label-position="bzLabelOpsition">
          <el-form-item label="货品ID" style="width:160px;float:left;">
            <el-input v-model="bz.goodsid" disabled="disabled" style="width:100px;"></el-input>
          </el-form-item>
          <el-form-item label="品名" style="float:left;">
            <el-input v-model="bz.goodsname" disabled="disabled"></el-input>
          </el-form-item>
          <el-form-item label="规格" style="width:160px;float: left">
            <el-input v-model="bz.goodstype" disabled="disabled" style="width:100px;"></el-input>
          </el-form-item>
          <el-form-item label="单位" style="width:160px;float: left">
            <el-input v-model="bz.goodsunit" disabled="disabled" style="width:100px;"></el-input>
          </el-form-item>
          <el-form-item label="产地" style="float:left;">
            <el-input v-model="bz.prodarea" disabled="disabled"></el-input>
          </el-form-item>
        </el-form>
        <el-table
          :data="bzTableData"
          border
          stripe
          :height="tableHeight"
        >
          <el-table-column prop="goodsunit" label="包装名称"></el-table-column>
          <el-table-column prop="unittype" label="包装类型ID"></el-table-column>
          <el-table-column prop="bzlxname" label="包装类型"></el-table-column>
          <el-table-column prop="baseunitqty" label="包装大小"></el-table-column>
          <el-table-column prop="goodsunitlength" label="长"></el-table-column>
          <el-table-column prop="goodsunitwidth" label="宽"></el-table-column>
          <el-table-column prop="goodsunitheight" label="高" :width="120"></el-table-column>
          <el-table-column prop="goodsunitweight" label="重量"></el-table-column>
          <el-table-column prop="goodsunitvol" label="容积"></el-table-column>
          <el-table-column prop="barcode" label="条码" :width="120"></el-table-column>
          <el-table-column prop="usestatus" label="状态ID"></el-table-column>
          <el-table-column prop="bzztname" label="状态"></el-table-column>
          <el-table-column prop="goodsunitid" label="货品包装ID"></el-table-column>
          <el-table-column prop="goodsid" label="货品ID"></el-table-column>
          <el-table-column :width="160" fixed="right">
            <template slot-scope="scope">
              <el-button type="primary" @click="updateBzxxDtl(scope.row)">修改</el-button>
              <el-button type="primary" @click="deleteBzxxDtl(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-form>
          <el-form-item>
            <el-button type="primary" size="small" round @click="openBzxxDtl">新增</el-button>
            <el-button type="info" size="small" round @click="docClose">取消</el-button>
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="货品质量信息" name="third">
        <el-form style="margin:0 auto;" :label-width="zlxxLabelWidth">
          <el-form-item label="货品ID" class="fl wd300">
            <el-input v-model="zlxx.goodsid" disabled="disabled"></el-input>
          </el-form-item>
          <el-form-item label="品名" class="fl wd300">
            <el-input v-model="zlxx.goodsname"></el-input>
          </el-form-item>
          <el-form-item label="效期"  class="fl wd300">
            <el-input v-model="zlxx.validperiod"></el-input>
          </el-form-item>
          <el-form-item label="期间单位"  class="fl wd300">
            <el-input v-model="zlxx.periodunit"></el-input>
          </el-form-item>
          <el-form-item label="仓储条件" class="fl wd300">
            <el-select v-model="zlxx.storagecondition" clearable>
              <el-option v-for="item in storageConditionOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="运输条件" class="fl wd300">
            <el-select v-model="zlxx.transcondition" clearable>
              <el-option v-for="item in transConditionOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="功能主治" style="clear:both;float:left;width:600px">
            <el-input v-model="zlxx.functionlist"></el-input>
          </el-form-item>
          <el-form-item label="用法用量" style="clear:both;float:left;width:600px;">
            <el-input v-model="zlxx.usage"></el-input>
          </el-form-item>
          <el-form-item label="包装是否合格" class="fl wd300">
            <el-select v-model="zlxx.packstandard" clearable>
              <el-option :value="0" label="不合格"></el-option>
              <el-option :value="1" label="合格"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="国家强制产品认证" class="fl wd300">
            <el-input v-model="zlxx.forcetypeno"></el-input>
          </el-form-item>
          <el-form-item label="产品说明书批件" class="fl wd300">
            <el-input v-model="zlxx.productapprovno"></el-input>
          </el-form-item>
          <el-form-item label="品牌" class="fl wd300">
            <el-input v-model="zlxx.brand"></el-input>
          </el-form-item>
          <el-form-item label="药监分类" class="fl wd300">
            <el-select v-model="zlxx.drugadminclass" clearable>
              <el-option v-for="item in drugadminClassOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="中/西药" class="fl wd300">
            <el-select v-model="zlxx.medicatype" clearable>
              <el-option :value="1" label="西药"></el-option>
              <el-option :value="2" label="中药"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="品牌等级" class="fl wd300">
            <el-select v-model="zlxx.brandgrade" clearable>
              <el-option v-for="item in brandGradeOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="上市时间" class="fl wd300">
            <el-date-picker type="datetime" v-model="zlxx.markettime" style="width:160px;"></el-date-picker>
          </el-form-item>
          <el-form-item label="广告品种"  class="fl wd300">
            <el-select v-model="zlxx.adflag" clearable>
              <el-option :value="0" label="非广告"></el-option>
              <el-option :value="1" label="广告"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="临床品种"  class="fl wd300">
            <el-select v-model="zlxx.clinicalflag" clearable>
              <el-option :value="0" label="非临床"></el-option>
              <el-option :value="1" label="临床"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="药品非药品" class="fl wd300">
            <el-select v-model="zlxx.drugsflag" clearable>
              <el-option :value="0" label="非药品"></el-option>
              <el-option :value="1" label="药品"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="资料类别" class="fl wd300">
            <el-select v-model="zlxx.informationclass" clearable>
              <el-option v-for="item in informationClassOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="样品" class="fl wd300">
            <el-select v-model="zlxx.sampleflag" clearable>
              <el-option :value="1" label="有"></el-option>
              <el-option :value="2" label="无"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="注册商标" class="fl wd300">
            <el-input v-model="zlxx.trademark"></el-input>
          </el-form-item>
          <el-form-item label="单方复方药" class="fl wd300">
            <el-select v-model="zlxx.compound"  clearable>
              <el-option :value="0" label="复方"></el-option>
              <el-option :value="1" label="单方"></el-option>
            </el-select>
          </el-form-item>
        <!--  <el-form-item label="药品本位码" class="fl wd300">
            <el-input v-model="zlxx.ccode"></el-input>
          </el-form-item>-->
          <el-form-item label="所属经营范围ID" class="fl wd300">
            <el-input v-model="zlxx.qualityscopeid" disabled="disabled" style="width:80%"></el-input>
            <el-button icon="el-icon-search" circle @click="openHov('qualityscopeid')"></el-button>
          </el-form-item>
          <el-form-item label="所属经营范围"  class="fl wd300">
            <el-input v-model="zlxx.qualityscopename" disabled="disabled"></el-input>
          </el-form-item>
          <el-form-item style="float:left;">
            <el-checkbox v-model="zlxx.iflotno" label="不跟踪批号" :true-label="1" :false-label="0"></el-checkbox>
          </el-form-item>
          <el-form-item style="float:left;">
            <el-checkbox v-model="zlxx.ccode" label="是否扫码标记" :true-label="1" :false-label="0"></el-checkbox>
          </el-form-item>
          <el-form-item style="clear:both;float:left;width:100%;">
            <el-button type="primary" size="small" round @click="zlxxInsert">保存</el-button>
            <el-button type="info" size="small" round @click="docClose">关闭</el-button>
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="采购经理" name="fourth">
        <el-form ref="cgjl" :model="cgjl" style="width:600px;margin:0 auto;" :label-width="cgjlLabelWidth">
          <el-form-item label="货品ID" class="fl wd300">
            <el-input v-model="cgjl.goodsid" disabled="disabled"></el-input>
          </el-form-item>
          <el-form-item label="货品ID" class="fl wd300">
            <el-input v-model="cgjl.goodsname" disabled="disabled"></el-input>
          </el-form-item>
          <el-form-item label="采购经理ID" style="clear:both" class="fl wd300" prop="managerid" :rules="[{required:true,message:'采购经理不能为空'}]">
            <el-input v-model="cgjl.managerid" style="width:80%;"></el-input>
            <el-button icon="el-icon-search" circle @click="openHov('managerid')"></el-button>
          </el-form-item>
          <el-form-item label="采购经理"  class="fl wd300">
            <el-input v-model="cgjl.managername"></el-input>
          </el-form-item>
          <el-form-item label="采购分组分类1" class="fl wd300">
            <el-select v-model="cgjl.class1" clearable>
              <el-option v-for="item in class1Options" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="采购分组分类2"  class="fl wd300">
            <el-input v-model="cgjl.class2"></el-input>
          </el-form-item>
          <el-form-item label="合作伙伴ID" class="fl wd300">
            <el-input v-model="cgjl.companyid" style="width:80%;"></el-input>
            <el-button icon="el-icon-search" circle @click="openHov('companyid')"></el-button>
          </el-form-item>
          <el-form-item label="合作伙伴" class="fl wd300">
            <el-input v-model="cgjl.companyname"></el-input>
          </el-form-item>
          <el-form-item label="A类分类" class="fl wd300">
            <el-select v-model="cgjl.classa" clearable>
              <el-option v-for="item in classAOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="合作伙伴类型" class="fl wd300">
            <el-select v-model="cgjl.companytype" clearable>
              <el-option v-for="item in companyTypeOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="品牌名称属性" class="fl wd300">
            <el-input v-model="cgjl.property"></el-input>
          </el-form-item>
          <el-form-item style="clear:both;float:left;">
            <el-button type="primary" size="small" round @click="cgjlInsert">保存</el-button>
            <el-button type="info" size="small" round @click="docClose">关闭</el-button>
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="组合品"  name="fire">
        <div style="width:100%;height:20px;text-align:left;margin-left:20px;margin-top:5px;">
          <el-radio v-model="zhpRadio" label="1">是</el-radio>
          <el-radio v-model="zhpRadio" label="2">否</el-radio>
        </div>
        <div style="width:100%;height:40px;text-align:left;margin-left:20px;">
          <el-button type="primary" size="small" round @click="zhpAdd">新增</el-button>
        </div>
        <el-table
          :data="zhpTableData"
          border
          stripe
          :height="tableHeight"
        >
          <el-table-column prop="subgoodsid" label="子货品ID"></el-table-column>
          <el-table-column prop="subname" label="子货品名称"></el-table-column>
          <el-table-column prop="subtype" label="规格"></el-table-column>
          <el-table-column prop="subunit" label="单位"></el-table-column>
          <el-table-column prop="subqty" label="数量"></el-table-column>
          <el-table-column prop="approvedocno" label="批准文号"></el-table-column>
          <el-table-column prop="subfact" label="生产企业" :width="120"></el-table-column>
          <el-table-column :width="160">
            <template slot-scope="scope">
              <el-button type="primary" @click="updateZhp(scope.row)">修改</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>
  </el-dialog>
  <el-dialog v-if="bzxxDtlVisiable" :visible.sync="bzxxDtlVisiable" :title="bzxxdtlTitle" :width="dialogWidth"
             :top="dialogTop" :destroy-on-close="true" :close-on-click-modal="false" @close="zbxxClose">
    <el-form ref="bzxxdtl" :model="bzxxDtl" :label-width="bzxxdtlLabelWidth">
      <el-form-item label="包装名称" style="float:left;" prop="goodsunit" :rules="[{required:true,message:'包装名称不能为空'}]">
        <el-input v-model="bzxxDtl.goodsunit" :disabled="bzxxDtlStatus"></el-input>
      </el-form-item>
      <el-form-item label="包装类型" style="float:left;" prop="unittype" :rules="[{required:true,message:'包装类型不能为空'}]">
        <el-select v-model="bzxxDtl.unittype">
          <el-option v-for="item in unitTypeOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="包装大小" style="clear:both;float:left;" prop="baseunitqty" :rules="[{required:true,message:'包装大小不能为空'}]">
        <el-input v-model="bzxxDtl.baseunitqty"></el-input>
      </el-form-item>
      <el-form-item label="长" style="float:left;">
        <el-input v-model="bzxxDtl.goodsunitlength"></el-input>
      </el-form-item>
      <el-form-item label="宽" style="float:left;">
        <el-input v-model="bzxxDtl.goodsunitwidth"></el-input>
      </el-form-item>
      <el-form-item label="高" style="clear:both;float:left;">
        <el-input v-model="bzxxDtl.goodsunitheight"></el-input>
      </el-form-item>
      <el-form-item label="重量" style="float:left;">
        <el-input v-model="bzxxDtl.goodsunitweight"></el-input>
      </el-form-item>
      <el-form-item label="容积" style="clear:both;float:left;">
        <el-input v-model="bzxxDtl.goodsunitvol"></el-input>
      </el-form-item>
      <el-form-item label="条码" style="float:left;">
        <el-input v-model="bzxxDtl.barcode"></el-input>
      </el-form-item>
      <el-form-item label="状态" style="clear:both;float:left;">
        <el-select v-model="bzxxDtl.usestatus">
          <el-option v-for="item in bzuseStatusOptions" :value="item.value" :key="item.value" :label="item.label"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item  style="clear:both;float:left;">
        <el-button type="info" size="small" round @click="zbxxClose">取消</el-button>
        <el-button type="primary" size="small" round @click="bzxxInsert">保存</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
  <el-dialog v-if="zhpDtlVisiable" :visible.sync="zhpDtlVisiable" :title="zhpdtlTitle" :width="dialogWidth"
             :top="dialogTop" :destroy-on-close="true" :close-on-click-modal="false" @close="zhpClose">
    <el-form :label-width="zhpDtlLabelWidth">
      <el-form-item label="子货品ID" style="float:left;">
        <el-input v-model.number="zhpDtl.subgoodsid" disabled="disabled" style="width:80%"></el-input>
        <el-button icon="el-icon-search" circle @click="openHov('goodsid')"></el-button>
      </el-form-item>
      <el-form-item label="子货品名称" style="float:left;">
        <el-input v-model="zhpDtl.subname"></el-input>
      </el-form-item>
      <el-form-item label="规格" style="clear:both;float:left;">
        <el-input v-model="zhpDtl.subtype"></el-input>
      </el-form-item>
      <el-form-item label="单位" style="float:left;">
        <el-input v-model="zhpDtl.subunit"></el-input>
      </el-form-item>
      <el-form-item label="数量" style="float:left;">
        <el-input v-model="zhpDtl.subqty"></el-input>
      </el-form-item>
      <el-form-item label="批准文号" style="clear:both;float:left;">
        <el-input v-model="zhpDtl.approvedocno"></el-input>
      </el-form-item>
      <el-form-item label="生产企业" style="float:left;">
        <el-input v-model="zhpDtl.subfact"></el-input>
      </el-form-item>
      <el-form-item  style="clear:both;float:left;">
        <el-button type="info" size="small" round @click="zhpClose">取消</el-button>
        <el-button type="primary" size="small" round @click="zhpInsert">保存</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
  <hov-tools v-if="baseFactVisible" :hov-data="baseFactHov"></hov-tools>
  <hov-tools v-if="baseCommissionVisible" :hov-data="baseCommissionHov"></hov-tools>
  <hov-tools v-if="zlxxQualityscopeVisible" :hov-data="zlxxQualityscopeHov"></hov-tools>
  <hov-tools v-if="cgjlManagerVisible" :hov-data="cgjlManagerHov"></hov-tools>
  <hov-tools v-if="cgjlCompanyVisible" :hov-data="cgjlCompanyHov"></hov-tools>
  <hov-tools v-if="zhpGoodsVisible" :hov-data="zhpGoodsHov"></hov-tools>
  <hov-tools v-if="zxcolumn4Visible" :hov-data="zxcolumn4Hov"></hov-tools>
</div>
</template>

<script>
//货品基础数据维护
import HovTools from "@/views/Core/HovTools";
export default {
  name: 'HpjcsjwhDtl',
  components:{HovTools},
  props:{
    dtlStatus:{type:Boolean},
    drugtypeOptions:{type:Array},
    usestatusOptions:{type:Array},
    storageConditionOptions:{type:Array},
    transConditionOptions:{type:Array},
    drugadminClassOptions:{type:Array},
    brandGradeOptions:{type:Array},
    informationClassOptions:{type:Array},
    class1Options:{type:Array},
    classAOptions:{type:Array},
    companyTypeOptions:{type:Array},
    unitTypeOptions:{type:Array},
    bzuseStatusOptions:{type:Array},
    dtlData:{type:Object},
    docTitle:{type:String}
  },
  data () {
    return {
      dialogVisible:true,
      dialogWidth:'1000px',
      dialogTop:'8vh',
      activeTabs:'first',
      companyid:null,
      tableHeight:424,
      goodsid:null,
      /*基本信息*/
      baseLabelWidth:'auto',
      labelOptions:'right',
      base:{
        goodsname:null,
        opcode:null,
        goodsformalname:null,
        goodstype:null,
        prodarea:null,
        goodstag:null,
        defaultpack:null,
        goodsunit:null,
        salestaxrate:null,
        sutaxrate:null,
        goodsformalpinyin:null,
        goodsno:null,
        goodsshortname:null,
        zxcolumn4:null,
        gbcode:null,
        standardcode:null,
        drugtype:null,
        usestatus:null,
        memo:null,
        zxcolumn3:null,
        shflmc:null,
        factid:null,
        factname:null,
        commissionid:null,
        commissionname:null,
        credate:null,
        inputmanid:Number(sessionStorage['userid']),
        inputmanname:sessionStorage['username'],
        companyid:null,
        jybf:false,
        ifimport:false,
        ifback:false,
        iforder:false,
        ifctrlzb:false,
        sflcpz:false,
        sfyypz:false
      },
      oldbase:{
        oldgbcode:null,
        oldprodarea:null,
        oldfactid:null
      },
      baseRules:{
        goodsname:{ required: true, message: '通用名称不能为空', trigger: 'blur' },
        opcode:{ required: true, message: '操作码不能为空', trigger: 'blur'},
        goodstype:{ required: true, message: '规格不能为空', trigger: 'blur'},
        prodarea:{ required: true, message: '产地不能为空', trigger: 'blur'},
        goodsunit:{ required: true, message: '基本单位不能为空', trigger: 'blur'},
        salestaxrate:{ required: true, message: '销售税率不能为空', trigger: 'change'},
        factid:{ required: true, message: '生产企业不能为空', trigger: 'blur'},
      },
      /*包装信息*/
      bzLabelWidth:'60px',
      bz:{
        goodsid:null,
        goodsname:null,
        goodstype:null,
        goodsunit:null,
        prodarea:null
      },
      bzLabelOpsition:'right',
      bzTableData:[],
      /*包装细单*/
      bzxxdtlLabelWidth:'100px',
      bzxxDtlVisiable:false,
      bzxxDtlStatus:false,
      bzxxdtlTitle:'',
      bzxxDtl:{
        goodsunit:null,
        unittype:null,
        baseunitqty:null,
        goodsunitlength:null,
        goodsunitwidth:null,
        goodsunitheight:null,
        goodsunitweight:null,
        goodsunitvol:null,
        barcode:null,
        usestatus:null,
        goodsid:null,
        goodsunitid:null
      },
      /*质量信息*/
      zlxxLabelWidth:'140px',
      zlxx:{
        goodsid:null,
        goodsname:null,
        validperiod:null,
        periodunit:null,
        storagecondition:null,
        transcondition:null,
        functionlist:null,
        usage:null,
        packstandard:null,
        forcetypeno:null,
        productapprovno:null,
        brand:null,
        drugadminclass:null,
        medicatype:null,
        brandgrade:null,
        markettime:null,
        adflag:null,
        clinicalflag:null,
        drugsflag:null,
        informationclass:null,
        sampleflag:null,
        trademark:null,
        compound:null,
        ccode:false,
        qualityscopeid:null,
        qualityscopename:null,
        iflotno:false
      },
      /*采购经理*/
      cgjlLabelWidth:'140px',
      cgjl:{
        goodsid:null,
        goodsname:null,
        managerid:null,
        managername:null,
        class1:null,
        class2:null,
        companyid:null,
        companyname:null,
        classa:null,
        companytype:null,
        property:null
      },
      /*组合品*/
      zhpRadio:"1",
      zhpTableData:[],
      /*组合品细单*/
      zhpDtlLabelWidth:'100px',
      zhpDtlVisiable:false,
      zhpDtlStatus:false,
      zhpdtlTitle:'',
      zhpDtl:{
        goodsid:null,
        subgoodsid:null,
        subname:null,
        subtype:null,
        subunit:null,
        subqty:null,
        approvedocno:null,
        oldapprovedocno:null,
        subfact:null,
        no:null
      },
      /*hov加载*/
      baseFactVisible:false,
      baseFactHov:{
      hovTitle:'生产企业查询',
        hovUrl: "companyidhov/selectcompanyid",
        afterStatus: false,
        fillDataName: "base",
        parentVisible:'baseFactVisible',
        hovColumns:
        [
        {id: "companyid", name: "生产企业ID",queryStatus:true,dataStatus:2,fillid:'factid'},
        {id: "companyname", name: "生产企业名称",queryStatus:true,dataStatus:1,fillid:'factname'},
        {id: "companyopcode", name: "生产企业操作码",queryStatus:true,dataStatus:1},
        ]
      },
      baseCommissionVisible:false,
      baseCommissionHov:{
        hovTitle:'委托加工企业查询',
        hovUrl: "companyidhov/selectcompanyid",
        afterStatus: false,
        fillDataName: "base",
        parentVisible:'baseCommissionVisible',
        hovColumns:
          [
            {id: "companyid", name: "企业ID",queryStatus:true,dataStatus:2,fillid:'commissionid'},
            {id: "companyname", name: "企业名称",queryStatus:true,dataStatus:1,fillid:'commissionname'},
            {id: "companyopcode", name: "企业操作码",queryStatus:true,dataStatus:1},
          ]
      },
      zlxxQualityscopeVisible:false,
      zlxxQualityscopeHov:{
        hovTitle:'所属经营范围查询',
        hovUrl: "qualityscopeidhov/select",
        afterStatus: false,
        fillDataName: "zlxx",
        parentVisible:'zlxxQualityscopeVisible',
        hovColumns:
          [
            {id: "qualityscopeid", name: "所属经营范围ID",queryStatus:true,dataStatus:2,fillid:'qualityscopeid'},
            {id: "scopename", name: "所属经营范围名称",queryStatus:false,dataStatus:1,fillid:'qualityscopename'},
            {id: "scopeno", name: "所属经营范围序号",queryStatus:false,dataStatus:1},
          ]
      },
      cgjlManagerVisible:false,
      cgjlManagerHov:{
        hovTitle:'采购经理查询',
        hovUrl: "buyeridhov/select",
        afterStatus: false,
        fillDataName: "cgjl",
        parentVisible:'cgjlManagerVisible',
        hovColumns:
          [
            {id: "buyerid", name: "采购经理ID",queryStatus:true,dataStatus:2,fillid:'managerid'},
            {id: "buyername", name: "采购经理名称",queryStatus:false,dataStatus:1,fillid:'managername'}
          ]
      },
      cgjlCompanyVisible:false,
      cgjlCompanyHov:{
        hovTitle:'合作伙伴查询',
        hovUrl: "companyidhov/selectcompanyid",
        afterStatus: false,
        fillDataName: "cgjl",
        parentVisible:'cgjlCompanyVisible',
        hovColumns:
          [
            {id: "companyid", name: "合作伙伴ID",queryStatus:true,dataStatus:2,fillid:'companyid'},
            {id: "companyname", name: "合作伙伴名称",queryStatus:false,dataStatus:1,fillid:'companyname'},
            {id: "companyopcode", name: "合作伙伴操作码",queryStatus:false,dataStatus:1},
          ]
      },
      zhpGoodsVisible:false,
      zhpGoodsHov:{
        hovTitle:'组合品查询',
        hovUrl: "goodsidhov/select",
        afterStatus: false,
        fillDataName: "zhpDtl",
        parentVisible:'zhpGoodsVisible',
        hovColumns:
          [
            {id: "goodsid", name: "子货品ID",queryStatus:true,dataStatus:2,fillid:'subgoodsid'},
            {id: "goodsname", name: "子货品名称",queryStatus:false,dataStatus:1,fillid:'subname'},
            {id: "goodsopcode", name: "子货品操作码",queryStatus:false,dataStatus:1},
            {id: "goodstype", name: "子货品规格",queryStatus:false,dataStatus:1,fillid:'subtype'},
            {id: "goodsunit", name: "子货品单位",queryStatus:false,dataStatus:1,fillid:'subunit'},
            {id: "gbcode", name: "子货品批准文号",queryStatus:false,dataStatus:1,fillid:'approvedocno'},
            {id: "prodarea", name: "子货品产地",queryStatus:false,dataStatus:1,fillid:'subfact'},
          ]
      },
      zxcolumn4Visible:false,
      zxcolumn4Hov:{
        hovTitle:'上市许可持有人查询',
        hovUrl: "companyidhov/selectcompanyid",
        afterStatus: false,
        fillDataName: "base",
        parentVisible:'zxcolumn4Visible',
        hovColumns:
          [
            {id: "companyid", name: "企业ID",queryStatus:true,dataStatus:2},
            {id: "companyname", name: "企业名称",queryStatus:true,dataStatus:1,fillid:'zxcolumn4'},
            {id: "companyopcode", name: "企业操作码",queryStatus:true,dataStatus:1}
          ]
      }
    }
  },
  created(){
    if(this.dtlStatus===true){
      this.goodsid=this.dtlData.goodsid;
      this.bz.goodsid=this.dtlData.goodsid;
      this.zlxx.goodsid=this.dtlData.goodsid;
      this.cgjl.goodsid=this.dtlData.goodsid;
      this.cgjl.goodsname=this.dtlData.goodsname;
      this.bz.goodsname=this.dtlData.goodsname;
      this.bz.goodstype=this.dtlData.goodstype;
      this.bz.goodsunit=this.dtlData.goodsunit;
      this.bz.prodarea=this.dtlData.prodarea;
      this.zlxx.goodsname=this.dtlData.goodsname;
      Object.keys(this.base).forEach(e => {
        this.base[e]=this.dtlData[e];
      });
      this.base.zxcolumn4=this.dtlData.ssxkcyr;
      this.base.factname=this.dtlData.fact_companyname;
      this.base.commissionname=this.dtlData.com_companyname;
      this.base.zxcolumn3=this.dtlData.cwspflbm;
      this.base.shflmc=this.dtlData.taxname;
      this.base.jybf=this.getReturnValue(this.dtlData.jybf);
      this.base.ifimport=this.getReturnValue(this.dtlData.ifimport);
      this.base.ifback=this.getReturnValue(this.dtlData.ifback);
      this.base.iforder=this.getReturnValue(this.dtlData.iforder);
      this.base.ifctrlzb=this.getReturnValue(this.dtlData.ifctrlzb);
      this.base.sflcpz=this.getReturnValue(this.dtlData.sflcpz);
      this.base.sfyypz=this.getReturnValue(this.dtlData.sfyypz);
      this.oldbase.oldfactid=this.dtlData.factid;
      this.oldbase.oldgbcode=this.dtlData.gbcode;
      this.oldbase.oldprodarea=this.dtlData.prodarea;
      if(this.dtlData.medicatype===0){
        this.zlxx.medicatype=null;
      }

    }
  },
  methods:{
    docClose(){
      this.$parent.hpjcsjwhVisible=false;
    },
    handleClick(tab,event){
      if(tab.name === 'second'){
        this.selectBzxx();
      }else if(tab.name === 'third'){
        this.selectZlxx();
      }else if(tab.name === 'fourth'){
        this.selectCgjl();
      }else if(tab.name === 'fire'){
        this.selectZhp();
      }
    },
    addBase(){
      let base=this.base;
      let params={};
      Object.keys(base).forEach(e => {
        params[e]=this.returnValue(base[e]);
      });
      params.companyid=Number(sessionStorage['companyid']);
      this.$refs.baseForm.validate((vaild) => {
        if(vaild){
          if (this.dtlStatus === false) {
            this.$api.hpjcsjwh.insertBase(params).then(res => {
              if (res.code === 200) {
                alert('保存成功,货品ID:'+Number(res.data));
                this.goodsid = Number(res.data);
                this.bz.goodsid = Number(res.data);
                this.bz.goodsname = this.base.goodsname;
                this.bz.goodstype = this.base.goodstype;
                this.bz.goodsunit = this.base.goodsunit;
                this.bz.prodarea = this.base.prodarea;
                this.zlxx.goodsid = Number(res.data);
                this.cgjl.goodsid = Number(res.data);
                this.cgjl.goodsname = this.base.goodsname;
              }
            }).catch(error => {
              return false;
            })
          } else if (this.dtlStatus === true) {
            params.goodsid = this.goodsid;
            params.oldfactid=this.oldbase.oldfactid;
            params.oldprodarea=this.oldbase.oldprodarea;
            params.oldgbcode=this.oldbase.oldgbcode;
            this.$api.hpjcsjwh.updateBase(params).then(res => {
              if (res.code === 200) {
                alert('修改成功');
              }
            }).catch(error => {
              return false;
            })
          }
        }else{
          return false;
        }
      })
    },
    /*包装信息*/
    openBzxxDtl(){
      this.bzxxdtlTitle='新增包装信息';
      this.bzxxDtlStatus=false;
      Object.keys(this.bzxxDtl).forEach(e => {
        this.bzxxDtl[e]=null;
      });
      this.bzxxDtl.goodsid=this.goodsid;
      this.bzxxDtlVisiable=true;
    },
    updateBzxxDtl(row){
      this.bzxxdtlTitle='修改包装信息';
      this.bzxxDtlStatus=true;
      Object.keys(this.bzxxDtl).forEach(e => {
        this.bzxxDtl[e]=row[e];
      });
      this.bzxxDtl.goodsid=this.goodsid;
      this.bzxxDtlVisiable=true;
    },
    bzxxInsert(){
      let params={};
      Object.keys(this.bzxxDtl).forEach(e=>{
        params[e]=this.bzxxDtl[e];
      });
      params.inputmanid=Number(sessionStorage['userid']);
      params.companyid=Number(sessionStorage['companyid']);
      this.$refs.bzxxdtl.validate((vaild) => {
        if (vaild) {
          if (this.bzxxDtlStatus === false) {
            if(params.usestatus===0){
              alert("新增状态不能为作废");
              return false;
            }
            this.$api.hpjcsjwh.insertBzxx(params).then(res => {
              if (res.code === 200) {
                alert('保存成功');
                this.selectBzxx();
                this.zbxxClose();
              }
            }).catch(error => {
              return false;
            })
          } else if (this.bzxxDtlStatus === true) {
            this.$api.hpjcsjwh.updateBzxx(params).then(res => {
              if (res.code === 200) {
                alert('修改成功');
                this.selectBzxx();
                this.zbxxClose();
              }
            }).catch(error => {
              return false;
            })
          }
        }else{
          return false;
        }
      })
    },
    selectBzxx(){
      if(this.goodsid===null){
        return false;
      }
      this.$api.hpjcsjwh.selectBzxx({goodsid:this.goodsid}).then(res => {
        if (res.code === 200) {
          this.bzTableData=res.data;
        }
      }).catch(error => {
        return false;
      })
    },
    deleteBzxxDtl(row){
      this.$api.hpjcsjwh.delBzxx(row.goodsunitid).then(res => {
        if (res.code === 200) {
          alert('删除成功');
          this.selectBzxx();
        }
      }).catch(error => {
        return false;
      })
    },
    zbxxClose(){
      this.bzxxDtlVisiable=false;
      Object.keys(this.bzxxDtl).forEach(e => {
        this.bzxxDtl[e]=null;
      });
    },
    /*质量信息*/
    zlxxInsert(){
      let params={};
      Object.keys(this.zlxx).forEach(e=>{
        params[e]=this.returnValue(this.zlxx[e]);
      });
      this.$api.hpjcsjwh.insertZlxx(params).then(res => {
        if(res.code === 200){
          alert('保存成功');
          this.zbxxClose();
        }
      }).catch(error => {
        return false;
      })
    },
    selectZlxx(){
      if(this.goodsid===null){
        return false;
      }
      this.$api.hpjcsjwh.selectZlxx({goodsid:this.goodsid}).then(res => {
        if(res.code === 200){
          Object.keys(this.zlxx).forEach(e=>{
            this.zlxx[e]=res.data[e];
          });
          if(this.zlxx.medicatype===0){
            this.zlxx.medicatype=null;
          }
          this.zlxx.iflotno = res.data.iflotno === '1';
          this.zlxx.sjsmbj = res.data.sjsmbj === '1';
        }
      }).catch(error => {
        return false;
      })
    },
    /*采购经理*/
    cgjlInsert(){
      let params={};
      Object.keys(this.cgjl).forEach(e=>{
        params[e]=this.cgjl[e];
      });
      this.$refs.cgjl.validate((vaild) => {
        if (vaild) {
          this.$api.hpjcsjwh.insertCgjl(params).then(res => {
            if (res.code === 200) {
              alert('保存成功');
              this.selectCgjl();
              this.zbxxClose();
            }
          }).catch(error => {
            return false;
          })
        }else{
          return false;
        }
      })
    },
    selectCgjl(){
      if(this.goodsid===null){
        return false;
      }
      this.$api.hpjcsjwh.selectCgjl({goodsid:this.goodsid}).then(res => {
        if(res.code === 200){
          Object.keys(this.cgjl).forEach(e=>{
            this.cgjl[e]=res.data[e];
          });
        }
      }).catch(error => {
        return false;
      })
    },
    /*组合品*/
    zhpAdd(){
      this.zhpdtlTitle='新增组合品信息';
      this.zhpDtlStatus=false;
      Object.keys(this.zhpDtl).forEach(e => {
        this.zhpDtl[e]=null;
      });
      this.zhpDtl.goodsid=this.goodsid;
      this.zhpDtl.oldapprovedocno=null;
      this.zhpDtlVisiable=true;
    },
    updateZhp(row){
      this.zhpdtlTitle='修改组合品信息';
      this.zhpDtlStatus=true;
      Object.keys(this.zhpDtl).forEach(e => {
        this.zhpDtl[e]=row[e];
      });
      this.zhpDtl.goodsid=this.goodsid;
      this.zhpDtl.oldapprovedocno=row.approvedocno;
      this.zhpDtlVisiable=true;
    },
    zhpInsert(){
      let params={};
      Object.keys(this.zhpDtl).forEach(e => {
        params[e]=this.zhpDtl[e]
      });
      params.inputmanid=Number(sessionStorage['userid']);
      params.companyid=Number(sessionStorage['companyid']);
      params.flag=this.zhpRadio;
      if(this.zhpDtlStatus===false){
        this.$api.hpjcsjwh.insertZhp(params).then(res => {
          if(res.code === 200){
            alert('保存成功');
            this.selectZhp();
            this.zhpClose();
          }
        }).catch(error => {
          return false;
        })
      }else if(this.zhpDtlStatus===true){
        this.$api.hpjcsjwh.updateZhp(params).then(res => {
          if(res.code === 200){
            alert('修改成功');
            this.selectZhp();
            this.zhpClose();
          }
        }).catch(error => {
          return false;
        })
      }
    },
    selectZhp(){
      if(this.goodsid===null){
        return false;
      }
      this.$api.hpjcsjwh.selectZhp({goodsid:this.goodsid}).then(res => {
        if (res.code === 200) {
          if(res.data.length===0){
            this.zhpRadio="2";
          }else if(res.data[0].zhpflag===1){
            this.zhpRadio="1";
          }else{
            this.zhpRadio="2";
          }
          this.zhpTableData=res.data;
        }
      }).catch(error => {
        return false;
      })
    },
    zhpClose(){
      this.zhpDtlVisiable=false;
      Object.keys(this.zhpDtl).forEach(e => {
        this.zhpDtl[e]=null;
      });
    },
    /*hov*/
    openHov(id){
      if(id === 'factid'){
        this.baseFactVisible = true;
      }else if(id === 'commissionid'){
        this.baseCommissionVisible = true;
      }else if(id === 'qualityscopeid'){
        this.zlxxQualityscopeVisible = true;
      }else if(id === 'managerid'){
        this.cgjlManagerVisible = true;
      }else if(id === 'companyid'){
        this.cgjlCompanyVisible = true;
      }else if(id === 'goodsid'){
        this.zhpGoodsVisible = true;
      }else if(id === 'zxcolumn4'){
        this.zxcolumn4Visible = true;
      }
    },
    returnValue(val){
      if(typeof val === "boolean"){
        if(val===true){
          return 1;
        }else{
          return 0
        }
      }else {
        return val;
      }
    },
    getReturnValue(val){
      if(val===0||val===null){
        return false;
      }else if(val===1){
        return true;
      }
    },
    zx3Keypress(e){
      if(e.keyCode === 13){
        this.zx3blur();
      }
    },
    zx3blur(){
      this.base.shflmc=null;
      this.$api.hpjcsjwh.selectssflbm({taxid:this.base.zxcolumn3.toString()}).then(res => {
        if (res.code === 200) {
          this.base.shflmc=res.data.taxname;
        }
      }).catch(error => {
        return false;
      })
    }
  }
}
</script>

<style>
  .hpjcsjwhdtl .el-dialog{max-height:624px;height:624px;}
  .hpjcsjwhdtl .el-dialog__body{padding:0 2px 20px 2px}
 .hpjcsjwhdtl .el-dialog__body .el-tabs__content{padding:5px;height:516px;overflow-y: auto;}
  .hpjcsjwhdtl #checkGroup .el-form-item__content .el-checkbox{margin-right: 2px}
  .hpjcsjwhdtl .wd300{width:300px;}
  .hpjcsjwhdtl .fl{float:left;}
  #bz .el-form-item__label-wrap{margin-left:0}
</style>
