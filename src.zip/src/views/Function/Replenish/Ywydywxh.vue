<template>
<div>
  <e-query ref="query" :form-list="formList" :form-data="formData" :btn-options="btnOptions" :label-width="labelWidth" @query="queryFunction" @openHov="openHov"></e-query>
  <e-table
    ref="doctable"
    :table-columns="tableColumns"
    :table-data="tableData"
    :table-height="tableHeight"
    :loading="loading"
    :table-width-status="widthStatus"
    @handle="handleFunction"
    @sizeChange="handleChange"
    @currentChange="handleChange"
  ></e-table>
  <div>
    <el-dialog v-if="dialogVisible" :visible.sync="dialogVisible" :title="dialogTitle" :width="dialogWidth"  :destroy-on-close="true" @close="closeDialog" :close-on-click-modal="false">
      <el-form :model="base" :inline="inline" :label-width="dialogLabelWidth">
        <el-form-item label="ID">
          <el-input v-model.number="base.id" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="用户ID">
          <el-input v-model.number="base.relid" :disabled="true" style="width:80%"></el-input>
          <el-button circle icon="el-icon-search" @click="openHov('membername')"></el-button>
        </el-form-item>
        <el-form-item label="用户名">
          <el-input v-model="base.membername"  :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="业务员ID">
          <el-input v-model="base.ywyid" :disabled="true" style="width:80%"></el-input>
          <el-button circle icon="el-icon-search" @click="openHov('dtlywyid')" v-if="dtlstatus===false"></el-button>
        </el-form-item>
        <el-form-item label="业务员">
          <el-input v-model="base.ecdfyusername" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="供应商ID">
          <el-input v-model="base.supplyid" :disabled="true" style="width:80%"></el-input>
          <el-button circle icon="el-icon-search" @click="openHov('dtlsupplyid')" v-if="dtlstatus===true"></el-button>
        </el-form-item>
        <el-form-item label="供应商">
          <el-input v-model="base.companyname" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="企业微信帐号">
          <el-input v-model="base.wxno"></el-input>
        </el-form-item>
        <el-form-item label="录入人ID" v-if="dtlstatus===false">
          <el-input v-model="base.inputmanid" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="录入人" v-if="dtlstatus===false">
          <el-input v-model="base.inputmanname" :disabled="true"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" style="text-align:center">
      <el-button type="primary" round @click="insertCdfk">保存</el-button>
      <el-button type="info" round @click="closeDialog">取消</el-button>
      </div>
    </el-dialog>
  </div>
  <hov-tools v-if="supplyVisible" :hov-data="supplyHov"></hov-tools>
  <hov-tools v-if="ywyVisible" :hov-data="ywyHov"></hov-tools>
  <hov-tools v-if="dtlMemberVisible" :hov-data="dtlMemberHov"></hov-tools>
  <hov-tools v-if="dtlYwyVisible" :hov-data="dtlYwyHov"></hov-tools>
  <hov-tools v-if="dtlSupplyVisible" :hov-data="dtlSupplyHov"></hov-tools>
</div>
</template>

<script>
//企业通讯录
import EQuery from "@/views/Core/EQuery";
import {exportExcelDOM, getNewDate, paramsFormat, selectDdl, selectDdlOption} from "@/utils/functions";
import HovTools from "@/views/Core/HovTools";
import ETable from "@/views/Core/ETable";
export default {
  name: 'Ywydywxh',
  components:{ETable, HovTools, EQuery},
  data(){
    return {
      labelWidth:'110px',
      formList:[
        {type:'inputHov', id:'supplyid', label:'供应商ID'},
        {type:'inputHov', id:'ywyid', label:'业务员ID'},
        {type:'input', id:'wxno', label:'企业微信账号'}
      ],
      formData:{
        supplyid:null,
        ywyid:null,
        wxno:null
      },
      btnOptions:[
        {id:'query', icon:"fa fa-search", label:"action.search", perms:"replenishment:ywydywxh:select"},
        {id:'add', icon:"fa fa-plus", label:"action.add", perms:"replenishment:ywydywxh:select"},
        {id:'download', icon:"fa fa-download", label:"action.download", perms:"replenishment:ywydywxh:select"}
      ],
      tableHeight:300,
      loading:false,
      widthStatus:false,
      tableColumns:[
        {prop:'id',label:'ID',type:0,tableStatus:0,width:70},
        {prop:'credate',label:'日期',type:2,tableStatus:0,width:140,widthStatus:true},
        {prop:'relid',label:'用户ID',type:0,tableStatus:0,width:70},
        {prop:'membername',label:'用户名',type:0,tableStatus:0},
        {prop:'supplyid',label:'供应商ID',type:0,tableStatus:0,width:70},
        {prop:'supplyname',label:'供应商',type:0,tableStatus:0,width:200},
        {prop:'ywyid',label:'业务员ID',type:0,tableStatus:0,width:70},
        {prop:'contactman',label:'业务员',type:0,tableStatus:0,width:70},
        {prop:'wxno',label:'企业微信帐号',type:0,tableStatus:0},
        {prop:'inputmanid',label:'录入人ID',type:0,tableStatus:0,width:70},
        {prop:'inputmanname',label:'录入人',type:0,tableStatus:0},
        {prop:'caozuo',label:'操作',type:1,fixed:'right',width:170,widthStatus:true,tableStatus:0,options:[
            {id:'edit',icon:"fa fa-edit", label:"action.edit",perms:"replenishment:ywydywxh:select"},
            {id:'delete',icon:"fa fa-delete", label:"action.delete",perms:"replenishment:ywydywxh:select"}
          ]
        }
      ],
      tableData:[],
      dtlstatus:false,
      dtlFormList:[],
      dialogVisible:false,
      dialogTitle:'',
      dialogWidth:'700px',
      inline:true,
      dialogLabelWidth:'100px',
      base:{
        id:null,
        relid:null,
        membername:null,
        ywyid:null,
        ecdfyusername:null,
        supplyid:null,
        companyname:null,
        wxno:null,
        inputmanid:null,
        inputmanname:null
      },
      supplyVisible:false,
      supplyHov:{
        hovTitle:'供应商查询',
        hovUrl: "customidhov/select",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'supplyVisible',
        hovColumns:
          [
            {id: "customid", name: "供应商ID",queryStatus:true,dataStatus:2,fillid:"supplyid"},
            {id: "customname", name: "供应商名称",queryStatus:true,dataStatus:1},
            {id: "customopcode", name: "供应商操作码",queryStatus:true,dataStatus:1}
          ]
      },
      ywyVisible:false,
      ywyHov:{
        hovTitle:'业务员查询',
        hovUrl: "contactinfoidhov/select",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'ywyVisible',
        hovColumns:
          [
            {id: "contactinfoid", name: "业务员ID",queryStatus:true,dataStatus:2,fillid:"ywyid"},
            {id: "contactman", name: "业务员名称",queryStatus:true,dataStatus:1},
          ]
      },
      dtlMemberVisible:false,
      dtlMemberHov:{
        hovTitle:'用户查询',
        hovUrl: "employeeididhov/select",
        afterStatus: false,
        fillDataName: "base",
        parentVisible:'dtlMemberVisible',
        hovColumns:
          [
            {id: "employeeid", name: "用户ID",queryStatus:true,dataStatus:2,fillid:"relid"},
            {id: "employeename", name: "用户名称",queryStatus:true,dataStatus:1,fillid:"membername"},
            {id: "employeeopcode", name: "用户操作码",queryStatus:true,dataStatus:1}
          ]
      },
      dtlYwyVisible:false,
      dtlYwyHov:{
        hovTitle:'业务员查询',
        hovUrl: "contactinfoidhov/select",
        afterStatus: false,
        fillDataName: "base",
        parentVisible:'dtlYwyVisible',
        hovColumns:
          [
            {id: "contactinfoid", name: "业务员ID",queryStatus:true,dataStatus:2,fillid:"ywyid"},
            {id: "contactman", name: "业务员名称",queryStatus:true,dataStatus:1,fillid:"ecdfyusername"},
            {id: "companyid", name: "供应商ID",queryStatus:false,dataStatus:1,fillid:"supplyid"},
            {id: "companyname", name: "供应商",queryStatus:false,dataStatus:1,fillid:"companyname"}
          ]
      },
      dtlSupplyVisible:false,
      dtlSupplyHov:{
        hovTitle:'供应商查询',
        hovUrl: "companyidhov/selectcompanyid",
        afterStatus: false,
        fillDataName: "base",
        parentVisible:'dtlSupplyVisible',
        hovColumns:
          [
            {id: "companyid", name: "供应商ID",queryStatus:true,dataStatus:2,fillid:"supplyid"},
            {id: "companyname", name: "供应商名称",queryStatus:true,dataStatus:1,fillid:"companyname"},
            {id: "companyopcode", name: "供应商操作码",queryStatus:true,dataStatus:1}
          ]
      },
    }
  },
  created(){
    this.tableHeight=(window.innerHeight-240);
  },
  methods:{
    queryFunction(data){
      if(data==='query'){
        let pageSize=this.$refs.doctable.pageSize;
        this.selectDoc(1,pageSize);
      }else if(data==="add"){
        this.dialogTitle='新增';
        this.dtlstatus=false;
        Object.keys(this.base).forEach(e=>{
          this.base[e]=null;
        });
        this.base.inputmanid=Number(sessionStorage['userid']);
        this.base.inputmanname=sessionStorage['username'];
        this.dialogVisible=true;
      }else if(data==="download"){
        exportExcelDOM(this.tableColumns,this.tableData,'企业通讯录'+getNewDate());
      }
    },
    handleChange(data){
      this.selectDoc(data.pageNum,data.pageSize);
    },
    selectDoc(pageNum,pageSize){
      this.$refs.query.collapse=false;
      let formData=this.formData;
      let params=paramsFormat(formData);
      this.loading=true;
      this.tableData=[];
      this.$api.ywydywxh.select({pageNum:pageNum,pageSize:pageSize,params:params}).then(res => {
        if(res.code === 200){
          this.tableData=Object.freeze(res.data.content);
          this.$refs.doctable.pageSize=res.data.pageSize;
          this.$refs.doctable.currentPage=res.data.pageNum;
          this.$refs.doctable.total=res.data.totalSize;
          this.loading=false;
        }
      }).catch(error => {
        this.loading=false;
        return false;
      })
    },
    handleFunction(data){
      if(data.id==="edit"){
        this.dialogTitle='修改';
        this.dtlstatus=true;
        Object.keys(this.base).forEach(e=>{
          this.base[e]=data.row[e];
        });
        this.base.ecdfyusername=data.row.contactman;
        this.base.companyname=data.row.supplyname;
        this.dialogVisible=true;
      }else if(data.id==="delete"){
        this.$api.ywydywxh.del(data.row.id).then(res => {
          if(res.code===200){
            alert("删除成功");
            this.queryFunction('query');
          }
        }).catch(error => {
          return false;
        })
      }
    },
    insertCdfk(){
      let params={};
      Object.keys(this.base).forEach(e=>{
        params[e]=this.base[e];
      });
      if(this.dtlstatus===false){
        this.$api.ywydywxh.insert(params).then(res => {
          if(res.code===200){
            alert("保存成功");
            this.closeDialog();
            this.queryFunction('query');
          }
        }).catch(error => {
          return false;
        })
      }else if(this.dtlstatus===true){
        this.$api.ywydywxh.update(params).then(res => {
          if(res.code===200){
            alert("修改成功");
            this.closeDialog();
            this.queryFunction('query');
          }
        }).catch(error => {
          return false;
        })
      }
    },
    openHov(id){
      if(id==="supplyid"){
        this.supplyVisible=true;
      }else if(id==="ywyid"){
        this.ywyVisible=true;
      }else if(id==="membername"){
        this.dtlMemberVisible=true;
      }else if(id==="dtlywyid"){
        this.dtlYwyVisible=true;
      }else if(id==="dtlsupplyid"){
        this.dtlSupplyVisible=true;
      }
    },
    closeDialog(){
      this.dialogVisible=false;
    }
  }
}
</script>

<style scoped>

</style>
