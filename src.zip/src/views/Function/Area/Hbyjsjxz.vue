<template>
<div
  v-loading="loading"
  element-loading-text="正在下载中,请耐心等待"
  element-loading-background="rgba(0, 0, 0, 0.8)"
  style="height:100%;"
>
  <div style="width:500px;margin:0 auto;">
    <el-form :model="base" label-width="40px;" label-position="right">
      <el-form-item label="日期" style="text-align:left;">
        <el-date-picker type="datetime" v-model="base.querydate"></el-date-picker>
      </el-form-item>
      <el-form-item style="text-align:left;margin-left:40px;">
        <el-radio label="1" v-model="base.stcompanyid">门店</el-radio>
        <el-radio label="4" v-model="base.stcompanyid">地区</el-radio>
      </el-form-item>
      <el-form-item style="text-align:left;margin-left:40px;">
        <el-radio label="0" v-model="base.type">进货</el-radio>
        <el-radio label="1" v-model="base.type">销售</el-radio>
        <el-radio label="2" v-model="base.type">库存</el-radio>
      </el-form-item>
    </el-form>
  </div>
  <div>
    <el-form>
      <el-form-item>
        <kt-button size="small" :icon="icon" :label="$t(label)" :perms="perms" type="primary" @click="xmlToStrings()"></kt-button>
      </el-form-item>
    </el-form>
  </div>
</div>
</template>

<script>
import KtButton from "@/views/Core/KtButton";
import {getNewDate,dateFormat} from "@/utils/functions";
import {downloadFile} from "@/utils/Blob";
export default {
  name: 'Hbyjsjxz',
  components:{KtButton},
  data(){
    return {
      icon:'',
      perms:'region:hbyjsjxz:select',
      loading:false,
      label:'action.downloadNumber',
      base:{
        querydate:null,
        stcompanyid:'1',
        type:'0'
      },
    }
  },
  created(){
    this.base.querydate=new Date(getNewDate() + ' 00:00:00');
  },
  methods:{
    xmlToStrings () {
      let startdate=null;
      let endofdate=null;
      let usedate=null;
      if(this.base.querydate===null||this.base.querydate===''){
        alert("日期不能为空");
        return false;
      }else {
       /* startdate=new Date(getNewDate(this.base.querydate) + " 00:00:00");
        endofdate=new Date(getNewDate(this.base.querydate) + " 23:59:59");*/
        startdate=dateFormat("YYYY-mm-dd",this.base.querydate) + " 00:00:00";
        endofdate=dateFormat("YYYY-mm-dd",this.base.querydate) + " 23:59:59";
        usedate=dateFormat("YYYY-mm-dd",this.base.querydate);
      }
      if(this.base.stcompanyid===null||this.base.stcompanyid===''){
        alert("类型为门店或者地区不能为空");
        return false;
      }
      if(this.base.type===null||this.base.type===''){
        alert("类型为进货,销售或者库存不能为空");
        return false;
      }
      if(this.base.type==='2'){
        downloadFile("/hbyjsjxz/selectrem?stcompanyid="+this.base.stcompanyid,this);
      }else if(this.base.type==='0'){
        downloadFile("/hbyjsjxz/selectsu?startdate="+startdate+"&endofdate="+endofdate+"&stcompanyid="+this.base.stcompanyid,this);
      }else if(this.base.type==='1'){
        downloadFile("/hbyjsjxz/selectsales?startdate="+startdate+"&endofdate="+endofdate+"&useday="+usedate+"&stcompanyid="+this.base.stcompanyid,this);
      }
    }
  }
}
</script>

<style scoped>

</style>
