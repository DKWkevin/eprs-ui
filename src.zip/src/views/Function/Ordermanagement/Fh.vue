<template>
<div>
  <e-query ref="query"
           :btn-options="btnOptions"
           :form-list="formList"
           :form-data="formData"
           @openHov="openHov"
           @query="queryFunction"
  ></e-query>
  <e-table
    ref="doctable"
    :table-columns="docTableColumns"
    :table-data="docTableData"
    :table-height="docTableHeight"
    :loading="loading"
    @handle="handleFunction"
    @currentChange="handleChange"
    @sizeChange="handleChange"
    @selectionChange="selectionChange"
  ></e-table>
  <!--<fh-execl v-if="execlVisible"></fh-execl>-->
  <execl-insert v-if="execlVisible" ref="execlInsert" :table-columns="execlColumns" :parentid="execlParentid" @insert="execlInsert"></execl-insert>
  <hov-tools v-if="inputmanVisible" :hov-data="inputmanHov"></hov-tools>
  <hov-tools v-if="supplyVisible" :hov-data="supplyHov"></hov-tools>
  <hov-tools v-if="goodsVisible" :hov-data="goodsHov"></hov-tools>
</div>
</template>

<script>
//分货
import EQuery from "@/views/Core/EQuery";
import HovTools from "@/views/Core/HovTools";
import ETable from "@/views/Core/ETable";
import {exportExcelDOM, getNewDate} from "@/utils/functions";
import {selectbuyid} from "@/utils/drops";
import FhExecl from "@/views/Function/Ordermanagement/FhExecl";
import ExeclInsert from "@/views/Core/ExeclInsert";
export default {
  name: 'Fh',
  components:{ExeclInsert, FhExecl, ETable, HovTools, EQuery},
  data(){
    return{
      btnOptions:[
        {id:'query', icon:"fa fa-search", label:"action.search", perms:"ordermanagement:fh:select"},
        {id:'download', icon:"fa fa-download", label:"action.download", perms:"ordermanagement:fh:select"},
        {id:'delAll', icon:"fa fa-download", label:"action.download", perms:"ordermanagement:fh:select"},
        {id:'uploads', icon:"fa fa-upload", label:"action.upload", perms:"ordermanagement:fh:select"}
      ],
      formList:[
        {type:'inputHov',id:'counterid',label:'门店ID'},
        {type:'inputHov',id:'goodsid',label:'货品ID'},
        {type:'inputHov',id:'inputmanid',label:'录入人ID'},
        {type:'datetimerange',id:'querydate',label:'日期'},
        {type:'inputHov',id:'cityid',label:'地区ID'},
      ],
      formData:{
        counterid:null,
        querydate:null,
        goodsid:null,
        inputmanid:null,
        cityid:null
      },
      loading:false,
      docTableHeight:0,
      docTableColumns:[
        {indexType:'selection',fixed:'left'},
        {prop:'orderid',label:'订单ID',type:0,tableStatus:0},
        {prop:'credate',label:'发生日期',type:2,tableStatus:0,width:150,widthStatus:true},
        {prop:'mdid',label:'门店ID',type:0,tableStatus:0},
        {prop:'companyname',label:'门店名称',type:0,tableStatus:0},
        {prop:'goodsid',label:'货品ID',type:0,tableStatus:0},
        {prop:'goodsname',label:'产品名称',type:0,tableStatus:0},
        {prop:'goodstype',label:'规格',type:0,tableStatus:0},
        {prop:'goodsunit',label:'单位',type:0,tableStatus:0},
        {prop:'prodarea',label:'产地',type:0,tableStatus:0},
        {prop:'goodsqty',label:'数量',type:0,tableStatus:0},
        {prop:'unitprice',label:'单价',type:0,tableStatus:0},
        {prop:'fpzt',label:'分配状态',type:0,tableStatus:0},
        {prop:'fpsl',label:'分配数量',type:0,tableStatus:0},
        {prop:'fprq',label:'分配日期',type:2,tableStatus:0,width:150,widthStatus:true},
        {prop:'reqdocid',label:'销售单号',type:0,tableStatus:0},
        {prop:'ecredate',label:'销售日期',type:2,tableStatus:0,width:150,widthStatus:true},
        {prop:'inputman',label:'录入人',type:0,tableStatus:0},
        {prop:'sourcetable',label:'订单类型',type:0,tableStatus:0},
        {prop:'caozuo',label:'操作',fixed:'right',type:1,width:100,widthStatus:true,tableStatus:0,options:[
            {id:'edit',icon:"fa fa-edit",label:"action.nullify",perms:"ordermanagement:fh:update"}
          ]
        }
      ],
      delArray:null,
      docTableData:[],
      execlVisible:false,
      goodsVisible:false,
      goodsHov:{
        hovTitle:'货品查询',
        hovUrl: "goodsidhov/select",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'goodsVisible',
        hovColumns:
          [
            {id: "goodsid", name: "货品ID",queryStatus:true,dataStatus:2,fillid:"goodsid"},
            {id: "goodsname", name: "货品名称",queryStatus:true,dataStatus:1},
            {id: "opcode", name: "货品操作码",queryStatus:true,dataStatus:1},
            {id: "goodstype", name: "规格",queryStatus:false,dataStatus:1},
            {id: "goodsunit", name: "单位",queryStatus:false,dataStatus:1},
            {id: "prodarea", name: "产地",queryStatus:false,dataStatus:1}
          ]
      },
      supplyVisible:false,
      supplyHov:{
        hovTitle:'供应商查询',
        hovUrl: "customidhov/select",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'supplyVisible',
        hovColumns:
          [
            {id: "customid", name: "供应商ID",queryStatus:true,dataStatus:2,fillid:"supplyid"},
            {id: "customname", name: "供应商名称",queryStatus:true,dataStatus:1},
            {id: "customopcode", name: "供应商操作码",queryStatus:true,dataStatus:1}
          ]
      },
      inputmanVisible:false,
      inputmanHov:{
        hovTitle:'录入人查询',
        hovUrl: "employeeididhov/select",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'inputmanVisible',
        hovColumns:
          [
            {id: "employeeid", name: "录入人ID",queryStatus:true,dataStatus:2,fillid:"inputmanid"},
            {id: "employeename", name: "录入人名称",queryStatus:true,dataStatus:1}
          ]
      },
      execlColumns:[
        {prop:'orderid',label:'订单ID',type:0,tableStatus:0},
        {prop:'credate',label:'发生日期',type:0,tableStatus:0,width:150,widthStatus:true},
        {prop:'mdid',label:'门店ID',type:0,tableStatus:0},
        {prop:'companyname',label:'门店名称',type:0,tableStatus:0},
        {prop:'goodsid',label:'货品ID',type:0,tableStatus:0},
        {prop:'goodsname',label:'产品名称',type:0,tableStatus:0},
        {prop:'goodstype',label:'规格',type:0,tableStatus:0},
        {prop:'goodsunit',label:'单位',type:0,tableStatus:0},
        {prop:'prodarea',label:'产地',type:0,tableStatus:0},
        {prop:'goodsqty',label:'数量',type:0,tableStatus:0},
        {prop:'unitprice',label:'单价',type:0,tableStatus:0},
        {prop:'fpzt',label:'分配状态',type:0,tableStatus:0},
        {prop:'fpsl',label:'分配数量',type:0,tableStatus:0},
        {prop:'fprq',label:'分配日期',type:2,tableStatus:0,width:150,widthStatus:true},
        {prop:'reqdocid',label:'销售单号',type:0,tableStatus:0},
        {prop:'ecredate',label:'销售日期',type:0,tableStatus:0,width:150,widthStatus:true},
        {prop:'inputman',label:'录入人',type:0,tableStatus:0},
        {prop:'sourcetable',label:'订单类型',type:0,tableStatus:0}
      ],
      execlParentid:'execlVisible'
    }
  },
  created(){
    this.docTableHeight=(window.innerHeight-240);
  },
  methods:{
    queryFunction(data){
      if(data === "query"){
        let pageSize=this.$refs.doctable.pageSize;
        this.selectDoc(1,pageSize);
      }else if(data === "download"){
        exportExcelDOM(this.docTableColumns,this.docTableData,'分货'+getNewDate())
      }else if(data==="delAll"){
        let delArray=this.delArray;
        let employeeid=Number(sessionStorage['userid']);
        let num=delArray.length;
        let params=[];
        delArray.forEach(e => {
          if(e.sourcetable===2){
            if(employeeid!==e.inputman){
              alert("当前登陆人不是录入人");
              return false;
            }
          }
          if(e.fpzt!==0){
            alert("分配状态不为0");
            return false;
          }
          params.push(e.reqdocid);
        });
        if(num===0){
          alert("没有选中记录");
          return false;
        }
        if(confirm('是否作废选中的记录?')){
          this.$api.zbshmdzjjh.delAll({params:params,delete_num:num}).then(res => {
            if(res.code === 200){
              if(res.data==="1"){
                alert("作废成功");
                this.queryFunction('query');
              }else{
                alert(res.msg);
                return false;
              }
            }
          }).catch(error => {
            return false;
          })
        }else{
          return false;
        }
      }else if(data==="uploads"){
        this.execlVisible=true;
      }
    },
    handleChange(data){
      this.selectDoc(data.pageNum,data.pageSize);
    },
    selectDoc(pageNum,pageSize){
      let params={};
      let formData=this.formData;
      Object.keys(formData).forEach(e => {
        if(e!=="querydate"){
          if(this.returnValue(formData[e])===true){
            params[e]=formData[e];
          }
        }
      });
      if(this.returnValue(formData.querydate)===true){
        params.startdate=formData.querydate[0];
        params.endofdate=formData.querydate[1];
      }
      if(Object.keys(params).length===0){
        params=null;
      }
      this.loading=true;
      this.$api.fh.selectDoc({pageNum:pageNum,pageSize:pageSize,params:params}).then(res => {
        if(res.code === 200){
          this.docTableData = res.data.content;
          this.$refs.doctable.pageNum=res.data.pageNum;
          this.$refs.doctable.pageSize=res.data.pageSize;
          this.$refs.doctable.total=res.data.totalSize;
          this.loading=false;
        }
      }).catch(error => {
        this.loading=false;
        return false;
      })
    },
    handleFunction(data){
      let employeeid=Number(sessionStorage['userid']);
      if((employeeid===data.row.employeeid&&data.row.sourcetable===2)||data.row.sourcetable===1){
        if(confirm("是否确认作废")){
          let params={};
          params.employeeid=employeeid;
          params.docid=data.row.docid;
          params.dtlid=data.row.dtlid;
          params.mdid=data.row.mdid;
          params.goodsid=data.row.goodsid;
          this.$api.fh.deldoc({params:params}).then(res => {
            if(res.code === 200){
              if(res.data==="1"){
                alert("作废成功");
                this.queryFunction('query');
              }else{
                alert(res.msg);
                return false;
              }
            }
          }).catch(error => {
            return false;
          })
        }else{
          return false;
        }
      }else{
        alert("不可作废");
        return false;
      }
    },
    execlInsert(data){
      let params={};
      params.data=[];
      data.forEach(e => {
        params.data.push(e);
      });
      this.$api.pfyspjbcz.addexcelCashier(params).then(res => {
        if(res.code === 200){
          if(res.data===1){
            alert("导入成功");
            this.refs.execlInsert.closeExecl();
          }else {
            console.log(res.msg);
            alert(res.data);
            return false;
          }
        }
      }).catch(error => {
        return false;
      })
    },
    selectionChange(val){
      this.delArray=val;
    },
    openHov(id){
      if(id==="supplyid"){
        this.supplyVisible=true;
      }else if(id==="goodsid"){
        this.goodsVisible=true;
      }else if(id === "inputmanid"){
        this.inputmanVisible=true;
      }
    },
    returnValue(data){
      return data !== null && data !== "";
    }
  }
}
</script>

<style scoped>

</style>
