<template>
<div id="execl">
  <div class="execlDiv">
    <div class="execl-header">
      <label class="label">导入</label>
      <a class="closeBtn" href="javascript:void(0)" @click="closeExecl()">X</a>
    </div>
    <div class="tableDiv">
      <div style="width:100%;height:25px;">
        <upload-button @upload="implUserExcel"></upload-button>
        <el-button type="primary" @click="saveAll" style="float:left;" :disabled="saveStatus">保存</el-button>
      </div>
      <div>
        <e-table
          :table-data="tableData"
          :table-columns="tableColumns"
          :table-height="tableHeight"
          :page-status="false"
        ></e-table>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import UploadButton from "@/views/Core/uploadButton";
import ETable from "@/views/Core/ETable";
import {dateFormat} from "@/utils/functions"
import XLSX from 'xlsx'
export default {
  name: 'FhExecl',
  components:{ETable, UploadButton},
  data(){
    return {
      saveStatus:true,
      tableHeight:430,
      tableColumns:[
        {prop:'orderid',label:'订单ID',type:0,tableStatus:0},
        {prop:'credate',label:'发生日期',type:0,tableStatus:0,width:150,widthStatus:true},
        {prop:'mdid',label:'门店ID',type:0,tableStatus:0},
        {prop:'companyname',label:'门店名称',type:0,tableStatus:0},
        {prop:'goodsid',label:'货品ID',type:0,tableStatus:0},
        {prop:'goodsname',label:'产品名称',type:0,tableStatus:0},
        {prop:'goodstype',label:'规格',type:0,tableStatus:0},
        {prop:'goodsunit',label:'单位',type:0,tableStatus:0},
        {prop:'prodarea',label:'产地',type:0,tableStatus:0},
        {prop:'goodsqty',label:'数量',type:0,tableStatus:0},
        {prop:'unitprice',label:'单价',type:0,tableStatus:0},
        {prop:'fpzt',label:'分配状态',type:0,tableStatus:0},
        {prop:'fpsl',label:'分配数量',type:0,tableStatus:0},
        {prop:'fprq',label:'分配日期',type:2,tableStatus:0,width:150,widthStatus:true},
        {prop:'reqdocid',label:'销售单号',type:0,tableStatus:0},
        {prop:'ecredate',label:'销售日期',type:0,tableStatus:0,width:150,widthStatus:true},
        {prop:'inputman',label:'录入人',type:0,tableStatus:0},
        {prop:'sourcetable',label:'订单类型',type:0,tableStatus:0}
      ],
      tableData:[]
    }
  },
  methods:{
    saveAll(){
      let params={};
      params.data=[];
      this.tableData.forEach(e => {
        params.data.push(e);
      });
      this.$api.pfyspjbcz.addexcelCashier(params).then(res => {
        if(res.code === 200){
          if(res.data===1){
            alert("导入成功");
            this.closeExecl();
          }else {
            console.log(res.msg);
            alert(res.data);
            return false;
          }
        }
      }).catch(error => {
        return false;
      })
    },
    implUserExcel(e){
      let fileName=e.target.files[0];
      let _this=this;
      let reader=new FileReader();
      reader.readAsBinaryString(fileName);
      let uploadData=[];
      reader.onload =function (e) {
        const workbook = XLSX.read(e.target.result, {type:"binary"});
        let sheetList = workbook.SheetNames;
        const ws=XLSX.utils.sheet_to_json(workbook.Sheets[sheetList]);
        ws.forEach(e=>{
          var sheetData={};
          _this.tableColumns.forEach(res => {
            Object.keys(e).forEach(es=>{
              if(es===res.label){
                sheetData[res.prop]=e[es];
              }
            })
          });
          uploadData.push(sheetData)
        });
        _this.saveStatus = uploadData.length <= 0;
        _this.tableData=uploadData;
      };
    },
    closeExecl(){
      this.$parent.execlStatus=false;
    }
  }
}
</script>

<style scoped>
#execl{width:100%;height:100%;position: fixed;top:0;left: 0;background: rgba(0,0,0,0.6);z-index: 99999}
  .execlDiv{width:800px;height:500px;background:white;margin:10% auto;border-radius: 5px;}
  a{text-decoration: none;}
  .execl-header{width:100%;height:40px;background:#eee;border-top-left-radius: 5px;border-top-right-radius: 5px;}
  .execl-header .label{line-height:40px;font-size:20px;font-family: 宋体,serif}
  .closeBtn{float:right;margin:10px 10px 0 0;font-size:20px;}
  .tableDiv{width:100%;height:460px;}
</style>
