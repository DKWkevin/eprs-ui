<template>
<div>
  <e-query ref="query"
  :form-list="formList"
  :form-data="formData"
  :btn-options="btnOptions"
   @opneHov="openHov"
   @query="functionQuery"
  ></e-query>
  <e-table
    ref="doctable"
    :table-columns="tableColumns"
    :table-data="tableData"
    :table-height="tableHeight"
    :loading="loading"
    @currentChange="handleChange"
    @sizeChage="handleChange"
    @hanlde="handleFunction"
  ></e-table>
    <el-dialog v-if="dialogVisible" :visible.sync="dialogVisible" :title="docTitle" :width="dialogWidth"
               :top="dialogTop" :destroy-on-close="true" :close-on-click-modal="false" @close="xufeidialogColse">
        <el-form :model="dtlFormData" label-position="right" label-width="100px" style="width:300px;margin:0 auto;">
          <el-form-item label="供应商ID">
            <el-input v-model="dtlFormData.supplyid" :disabled="true" style="width:80%"></el-input>
            <el-button icon="el-icon-search" circle @click="openHov('dtlsupplyid')"></el-button>
          </el-form-item>
          <el-form-item label="供应商名称">
            <el-input v-model="dtlFormData.supplyname" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="货品ID">
            <el-input v-model="dtlFormData.goodsid" style="width:80%" :disabled="true"></el-input>
            <el-button icon="el-icon-search" circle @click="openHov('dtlgoodsid')"></el-button>
          </el-form-item>
          <el-form-item label="品名">
            <el-input v-model="dtlFormData.goodsname" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="规格">
            <el-input v-model="dtlFormData.goodstype"  :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="单位">
            <el-input v-model="dtlFormData.goodsunit" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="产地">
            <el-input v-model="dtlFormData.prodarea" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="状态">
            <el-input v-model="dtlFormData.usestatus" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="服务效期至">
            <el-input v-model="dtlFormData.validdate" :disabled="true"></el-input>
          </el-form-item>
        </el-form>
      <div slot="footer" style="text-align:center">
        <el-button type="primary" @click="insertForm" :loading="btnLoading">保存</el-button>
        <el-button type="info" @click="dialogColse">取消</el-button>
      </div>
    </el-dialog>
  <el-dialog v-if="xufeiVisible" :visible.sync="xufeiVisible" :title="docTitle" :width="dialogWidth"
             :top="dialogTop" :destroy-on-close="true" :close-on-click-modal="false" @close="dialogColse">
    <el-form :model="xufei" label-position="right" label-width="100px" style="width:300px;margin:0 auto;">
      <el-form-item label="缴费类型">
        <el-select v-model="xufei.standardname">
          <el-option v-for="item in standardnameOptions" :key="item.value" :value="item.value" :label="item.label"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="金额">
        <el-input v-model="xufei.total" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="货品ID">
        <el-input v-model="xufei.goodsid" style="width:80%" :disabled="true"></el-input>
        <el-button icon="el-icon-search" circle @click="openHov('dtlsupplyid')"></el-button>
      </el-form-item>
      <el-form-item label="品名">
        <el-input v-model="xufei.goodsname" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="规格">
        <el-input v-model="xufei.goodstype"  :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="单位">
        <el-input v-model="xufei.grade" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="产地">
        <el-input v-model="xufei.prodarea" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="效期">
        <el-input v-model="xufei.validdate" :disabled="true"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" style="text-align:center">
      <el-button type="primary" @click="insertXufei" :loading="btnLoading">续费</el-button>
      <el-button type="info" @click="xufeidialogColse">取消</el-button>
    </div>
  </el-dialog>
  <hov-tools v-if="supplyVisible" :hov-data="supplyHov"></hov-tools>
  <hov-tools v-if="dtlsupplyVisible" :hov-data="dtlsupplyHov"></hov-tools>
  <hov-tools v-if="goodsVisible" :hov-data="goodsHov"></hov-tools>
  <hov-tools v-if="dtlgoodsVisible" :hov-data="dtlgoodsHov"></hov-tools>
</div>
</template>

<script>
import EQuery from "@/views/Core/EQuery";
import ETable from "@/views/Core/ETable";
import '@/assets/css/dialog.css';
import {exportExcelDOM, getNewDate, paramsFormat} from "@/utils/functions";
import HovTools from "@/views/Core/HovTools";
export default {
  name: 'Llgyshpwh',
  components:{HovTools, ETable, EQuery},
  data(){
    return{
      formList:[
        {type:'inputHov',id:'supplyid',label:'供应商ID'},
        {type:'inputHov',id:'goodsid',label:'供应商ID'},
      ],
      formData:{supplyid:null,goodsid:null},
      btnOptions:[
        {id:'query',icon:"fa fa-search", label:"action.search",perms:"onlineflow:llgyskhxf:select"},
        {id:'add',icon:"fa fa-plus", label:"action.add",perms:"onlineflow:llgyskhxf:select"},
        {id:'download',icon:"fa fa-download", label:"action.download",perms:"onlineflow:llgyskhxf:select"}
      ],
      tableHeight:0,
      loading:false,
      tableColumns:[
        {type:0,prop:'relationid',label:'序列号',tableStatus:0},
        {type:0,prop:'supplyid',label:'供应商ID',tableStatus:0},
        {type:0,prop:'companyname',label:'供应商名称',tableStatus:0},
        {type:0,prop:'goodsid',label:'货品ID',tableStatus:0},
        {type:0,prop:'goodsname',label:'品名',tableStatus:0},
        {type:0,prop:'goodstype',label:'规格',tableStatus:0},
        {type:0,prop:'goodsunit',label:'单位',tableStatus:0},
        {type:0,prop:'prodarea',label:'产地',tableStatus:0},
        {type:0,prop:'usestatus',label:'状态',tableStatus:0},
        {type:2,prop:'validdate',label:'服务效期至',tableStatus:0,width:150,widthStatus:true},
        {type:1,prop:'caozuo',label:'操作',tableStatus:0,fixed:'right',width:280,widthStatus:true,options:[
            {id:'stop',label:'action.stop',icon:'fa fa-edit',perms:'onlineflow:llgyskhxf:select'},
            {id:'recovery',label:'action.recovery',icon:'fa fa-edit',perms:'onlineflow:llgyskhxf:select'},
            {id:'xufei',label:'action.delete',icon:'fa fa-edit',perms:'onlineflow:llgyskhxf:select'}
          ]}
      ],
      tableData:[],
      dialogVisible:false,
      docTitle:"",
      dialogWidth:'700px',
      dialogHeight:500,
      dialogTop:'12vh',
      dtlTableHeight:300,
      btnLoading:false,
      dtlFormData:{
        supplyid:null,
        supplyname:null,
        goodsid:null,
        goodsname:null,
        goodstype:null,
        goodsunit:null,
        proderea:null,
        usestatus:null,
        validdate:null,
      },
      xufeiVisible:false,
      xufei:{
        standardname:null,
        total:null,
        goodsid:null,
        goodsname:null,
        goodstype:null,
        goodsunit:null,
        proderea:null,
        validdate:null
      },
      standardnameOptions:[],
      supplyVisible:false,
      supplyHov:{
        hovTitle:'供应商查询',
        hovUrl: "companyidhov/selectcompanyid",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'supplyHov',
        hovColumns:
          [
            {id: "companyid", name: "供应商ID",queryStatus:true,dataStatus:2,fillid:"supplyid"},
            {id: "companyname", name: "供应商名称",queryStatus:true,dataStatus:1},
            {id: "companyopcode", name: "供应商操作码",queryStatus:true,dataStatus:1}
          ]
      },
      goodsVisible:false,
      goodsHov:{
        hovTitle:'货品查询',
        hovUrl: "goodsidhov/select",
        afterStatus: false,
        fillDataName: "formData",
        parentVisible:'goodsVisible',
        hovColumns:
          [
            {id: "goodsid", name: "货品ID",queryStatus:true,dataStatus:2,fillid:"goodsid"},
            {id: "goodsname", name: "货品名称",queryStatus:true,dataStatus:1},
            {id: "opcode", name: "货品操作码",queryStatus:true,dataStatus:1},
            {id: "goodstype", name: "规格",queryStatus:false,dataStatus:1},
            {id: "goodsunit", name: "单位",queryStatus:false,dataStatus:1},
            {id: "prodarea", name: "产地",queryStatus:false,dataStatus:1}
          ]
      },
      dtlsupplyVisible:false,
      dtlsupplyHov:{
        hovTitle:'供应商查询',
        hovUrl: "companyidhov/selectcompanyid",
        afterStatus: false,
        fillDataName: "dtlFormData",
        parentVisible:'dtlsupplyVisible',
        hovColumns:
          [
            {id: "companyid", name: "供应商ID",queryStatus:true,dataStatus:2,fillid:"supplyid"},
            {id: "companyname", name: "供应商名称",queryStatus:true,dataStatus:1,fillid:"supplyname"},
            {id: "companyopcode", name: "供应商操作码",queryStatus:true,dataStatus:1}
          ]
      },
      dtlgoodsVisible:false,
      dtlgoodsHov:{
        hovTitle:'货品查询',
        hovUrl: "goodsidhov/select",
        afterStatus: false,
        fillDataName: "dtlFormData",
        parentVisible:'dtlgoodsVisible',
        hovColumns:
          [
            {id: "goodsid", name: "货品ID",queryStatus:true,dataStatus:2,fillid:"goodsid"},
            {id: "goodsname", name: "货品名称",queryStatus:true,dataStatus:1,fillid:"goodsname"},
            {id: "opcode", name: "货品操作码",queryStatus:true,dataStatus:1},
            {id: "goodstype", name: "规格",queryStatus:false,dataStatus:1,fillid:"goodstype"},
            {id: "goodsunit", name: "单位",queryStatus:false,dataStatus:1,fillid:"goodsunit"},
            {id: "prodarea", name: "产地",queryStatus:false,dataStatus:1,fillid:"prodarea"}
          ]
      },
    }
  },
  created(){
    this.tableHeight=(window.innerHeight-240);
  },
  methods:{
    functionQuery(data){
      if(data==="query"){
        let pageSize=this.$refs.doctable.pageSize;
        this.selectDoc(1,pageSize);
      }else if(data==="add"){
        this.doctype=0;
        this.docTitle="新增表单";
        this.dtlFormData.usestatus='正常';
        this.dialogVisible=true;
      }else if(data==="download"){
        let columns=[];
        this.tableColumns.map((e,index)=>{
          if(index!==0){
            columns.push(e);
          }
        });
        exportExcelDOM(columns,this.tableData,"辽连供应商货品维护"+getNewDate())
      }
    },
    handleChange(data){
      this.selectDoc(data.pageNum,data.pageSize);
    },
    selectDoc(pageNum,pageSize){
      this.$refs.query.collapse=false;
      let formData=this.formData;
      let params=paramsFormat(formData);
      this.loading=true;
      this.tableData=[];
      this.$api.onlineflow.selectLlgyhpwh({pageNum:pageNum,pageSize:pageSize,params:params}).then(res=>{
        if(res.code===200){
          this.tableData=Object.freeze(res.data.content);
          this.$refs.doctable.pageNum=res.data.pageNum;
          this.$refs.doctable.pageSize=res.data.pageSize;
          this.$refs.doctable.total=res.data.totalSize;
          this.loading=false;
        }
      }).catch(error=>{
        this.loading=false;
        return false;
      })
    },
    handleFunction(data){
      if(data.id==="stop"){
        if(confirm("是否停用")===true){
          this.$api.onlineflow.stopLlgyshpwh({relationid:data.row.relationid}).then(res=>{
            if(res.code===200){
              if(res.data===1){
                alert("停用成功");
                this.functionQuery('query');
              }else {
                alert(res.msg);
                return false;
              }
            }
          }).catch(error=>{
            return false;
          })
        }else {
          alert("已经取消操作");
          return false;
        }
      }else if(data.id==="recovery"){
        if(confirm("是否恢复")===true){
          this.$api.onlineflow.recoveryLlgyshpwh({relationid:data.row.relationid}).then(res=>{
            if(res.code===200){
              if(res.data===1){
                alert("恢复成功");
                this.functionQuery('query');
              }else {
                alert(res.msg);
                return false;
              }
            }
          }).catch(error=>{
            return false;
          })
        }else {
          alert("已经取消操作");
          return false;
        }
      }else if(data.id==="xufei"){
        this.docTitle='续费';
        if(data.row.usestatus==="停用"){
          alert("已停用请先恢复再续费！");
          return false;
        }
        this.$api.onlineflow.selectLlgyhpwhfXufei({relationid:data.row.relationid,supplyid:data.row.supplyid,goodsid:data.row.goodsid}).then(res=>{
          if(res.code===200){
            Object.keys(this.xufei).forEach(e=>{
              this.xufei[e]=res.data[e];
            });
            this.xufeiVisible=true;
          }
        }).catch(error=>{
          return false;
        })
      }
    },
    //新增
    insertForm(){
      this.$api.onlineflow.insertLlgyshpwh(this.dtlFormData).then(res=>{
        if(res.code===200){
          if(res.data===1){
            alert("新增成功");
            this.dialogColse();
            this.functionQuery('query');
          }else {
            alert(res.msg);
            return false;
          }
        }
      }).catch(error=>{
        return false;
      })
    },
    //续费保存
    insertXufei(){
      let params={};
      Object.keys(this.xufei).keys(e=>{
        params[e]=this.xufei[e];
      });
      params.emlployeeid=Number(sessionStorage['userid']);
      this.$api.onlineflow.llgyshpwhxufei(params).then(res=>{
        if(res.code===200){
          if(res.data===1){
            alert("续费成功");
            this.xufeiVisible=false;
            this.functionQuery('query');
          }else {
            alert(res.msg);
            return false;
          }
        }
      }).catch(error=>{
        return false;
      })
    },
    dialogColse(){
      Object.keys(this.dtlFormData).forEach(e=>{
        this.dtlFormData[e]=null;
      });
      this.dialogVisible=false;
    },
    xufeidialogColse(){
      Object.keys(this.xufei).forEach(e=>{
        this.xufei[e]=null;
      });
      this.xufeiVisible=false;
    },
    openHov(data){
      if(data==="supplyid"){
        this.supplyVisible=true;
      }else if(data==="dtlsupplyid"){
        this.dtlsupplyVisible=true;
      }else if(data==="goodsid"){
        this.goodsVisible=true;
      }else if(data==="dtlgoodsid"){
        this.dtlgoodsVisible=true;
      }
    }
  }
}
</script>

<style scoped>

</style>
