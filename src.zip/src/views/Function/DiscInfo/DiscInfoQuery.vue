<template>
<div>
  <e-query 
	:form-list="formList" 
	:form-data="formData" 
	:btn-options="btnOptions"
	@query="queryFunction"
	></e-query>
  <e-table
	ref="doctable"
	:table-columns="tableColumns"
	:table-data="tableData"
  :table-height="tableHeight"
  :loading="loading"
  :table-width-status="widthStatus"
	@currentChange="handleChange"
	@sizeChange="handleChange"
	@handle="handleFunction"
	></e-table>
  <div v-if="dtlStatus" id="dtlDialogDiv">
    <el-dialog :visible="dtlDialog" width="70%" title="明细查询" @close="dtlDialogClose">
      <el-tabs v-model="dtlIndex" v-loading="dtlLoading" @tab-click="handleClick">
        <el-tab-pane label="可用门店" name="counter">
          <e-table
            ref="doctable"
            :table-columns="counterColumns"
            :table-data="counterData"
            :table-height="dtltableHeight"
            :table-width-status="widthStatus"
            :page-status="dtlpageStatus"
          ></e-table>
        </el-tab-pane>
        <el-tab-pane label="效期折扣方案" name="discCount">
          <e-table
            ref="doctable"
            :table-columns="disccountColumns"
            :table-data="disccountData"
            :table-height="dtltableHeight"
            :table-width-status="widthStatus"
            :page-status="dtlpageStatus"
          ></e-table>
        </el-tab-pane>
        <el-tab-pane label="效期折扣货品限定" name="discCountLimit">
          <e-table
            ref="doctable"
            :table-columns="invalidLimitColumns"
            :table-data="invalidLimitData"
            :table-height="dtltableHeight"
            :table-width-status="widthStatus"
            :page-status="dtlpageStatus"
          ></e-table>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
  </div>
</div>
</template>

<script>
import EQuery from "../../Core/EQuery";
import ETable from "../../Core/ETable";
export default {
  name: 'DiscInfoQuery',
  components:{ETable, EQuery},
  data(){
    return {
      formList:[
        {type:'input',label:'促销方案ID',id:'discid'},
				{type:'input',label:'促销方案名称',id:'discname'}
      ],
      formData:{
        discid:null,
				discname:null
      },
      btnOptions:[
        {id:"query",icon:"fa fa-search",label:"action.search",perms:'region:cxfacx:select'}
      ],
      tableColumns:[
        {type:0,prop:'discid',label:'促销方案ID',tableStatus:0},
				{type:0,prop:'discname',label:'方案名称',tableStatus:0},
				/*{type:0,prop:'discclassid',label:'促销类别ID',tableStatus:0},*/
				{type:0,prop:'discclassname',label:'促销类别',tableStatus:0},
				{type:2,prop:'begindate',label:'起始日期',tableStatus:0},
				{type:2,prop:'enddate',label:'终止日期',tableStatus:0},
        {type:0,prop:'employeeid',label:'确认人ID',tableStatus:0},
				{type:0,prop:'usestatusname',label:'状态',tableStatus:0},
				{type:0,prop:'cardtypeid',label:'会员卡类型ID',tableStatus:0},
				{type:0,prop:'counterflagname',label:'门店状态',tableStatus:0},
				{prop:'caozuo',label:'操作',fixed:'right',type:1,width:260,widthStatus:true,tableStatus:0,options:[
            {id:"dtl",icon:"fa fa-edit",label:"action.dtl",perms:'region:cxfacx:select'},
						{id:"comfirm",icon:"fa fa-edit",label:"action.comfirmThis",perms:'region:cxfacx:update'},
            {id:"delete",icon:"fa fa-edit",label:"action.nullify",perms:'region:cxfacx:update'}
          ]}
      ],
      tableData:[],
			loading:false,
      widthStatus:false,
      tableHeight:0,
      dtlStatus:false,
      dtlDialog:true,
      counterColumns:[
        {type:0,prop:'counterid',label:'门店ID',tableStatus:0},
        {type:0,prop:'countername',label:'门店名称',tableStatus:0},
        {type:0,prop:'cityid',label:'地区ID',tableStatus:0},
        {type:0,prop:'cityname',label:'地区名称',tableStatus:0}
      ],
      counterData:[],
      disccountColumns:[
        {type:0,prop:'dtlid',label:'明细ID',tableStatus:0},
        {type:0,prop:'invalidmonth',label:'近效期月数',tableStatus:0},
        {type:0,prop:'discrate',label:'折扣',tableStatus:0},
        {type:0,prop:'supplydisc',label:'供应商折扣',tableStatus:0},
        {type:0,prop:'saledisc',label:'零售商折扣',tableStatus:0}
      ],
      disccountData:[],
      invalidLimitColumns:[
        {type:0,prop:'limitdtlid',label:'明细ID',tableStatus:0},
        {type:0,prop:'goodsid',label:'货品ID',tableStatus:0},
        {type:0,prop:'goodsname',label:'货品名称',tableStatus:0},
        {type:0,prop:'goodstype',label:'货品规格',tableStatus:0},
        {type:0,prop:'goodsunit',label:'货品单位',tableStatus:0},
        {type:0,prop:'prodarea',label:'货品产地',tableStatus:0},
        {type:0,prop:'invalidmonth',label:'近效期月数',tableStatus:0},
        {type:0,prop:'discrate',label:'折扣',tableStatus:0},
        {type:0,prop:'supplydisc',label:'供应商折扣',tableStatus:0},
        {type:0,prop:'saledisc',label:'零售商折扣',tableStatus:0}
      ],
      invalidLimitData:[],
      dtltableHeight:400,
      dtlpageStatus:false,
      dtlLoading:false,
      dtlIndex:'counter',
      discid:null
    }
  },
  created(){
    this.tableHeight = (window.innerHeight - 240);
  },
	methods:{
		queryFunction(data){
			let pageSize = this.$refs.doctable.pageSize;
			this.selectDoc(1,pageSize);
		},
		handleChange(data){
			this.selectDoc(data.pageNum,data.pageSize);
		},
		selectDoc(pageNum,pageSize){
			let params = {};
			let formData = this.formData;
			if(formData.discid!==null&&formData.discid!==""){
				params.discid = formData.discid;
			}
			if(formData.discname!==null&&formData.discname!==""){
				params.discname = formData.discname;
			}
      params.companyid = Number(sessionStorage['companyid']);
      this.tableData = [];
			this.loading = true;
			this.$api.discInfo.selectDoc({pageNum:pageNum,pageSize:pageSize,params:params}).then(res => {
				if(res.code === 200){
					this.tableData = res.data.content;
					this.$refs.doctable.pageSize = res.data.pageSize;
					this.$refs.doctable.currentPage = res.data.pageNum;
					this.$refs.doctable.total = res.data.totalSize;
					this.loading=false;
				}
			}).catch(error => {
				this.loading=false;
				return false;
			})
		},
		handleFunction(data) {
      if (data.id === "comfirm") {
        if (data.row.usestatus !== 1) {
          alert("该状态不可操作");
          return false;
        }
        if (confirm("是否确认") === true) {
          let params = {discid:data.row.discid, checkmanid:Number(sessionStorage['userid']), usestatus:2};
          this.$api.discInfo.discInfoComfirm(params).then(res => {
            if (res.code === 200) {
              if (res.data === 1) {
                alert("确认成功");
                let pageSize = this.$refs.doctable.pageSize;
                let pageNum = this.$refs.doctable.currentPage;
                this.selectDoc(pageNum, pageSize);
              }
            }
          }).catch(error => {
            return false;
          });
        } else {
          return false;
        }
      } else if (data.id === "delete") {
        if (data.row.usestatus === 0) {
          alert("该状态不可操作");
          return false;
        }
        if (confirm("是否作废") === true) {
          let params = {discid:data.row.discid, invalidmanid:Number(sessionStorage['userid']), usestatus:0};
          this.$api.discInfo.discInfoDelete(params).then(res => {
            if (res.code === 200) {
              if (res.data === 1) {
                alert("作废成功");
                let pageSize = this.$refs.doctable.pageSize;
                let pageNum = this.$refs.doctable.currentPage;
                this.selectDoc(pageNum, pageSize);
              }
            }
          }).catch(error => {
            return false;
          });
        }
      }else if(data.id === "dtl"){
        this.discid = data.row.discid;
        this.selectCounter(data.row.discid);
      }
		},
    selectCounter(value){
      this.dtlStatus = true;
      this.counterData = [];
      let params = {discid:value};
      this.dtlLoading = true;
      this.$api.discInfo.discInfoQueryCounter(params).then(res => {
        if (res.code === 200) {
          this.counterData = res.data;
          this.dtlLoading =false;
        }
      }).catch(error => {
        this.dtlLoading =false;
        return false;
      });
    },
    selectDiscCount(value){
      this.dtlStatus = true;
      this.disccountData = [];
      let params = {discid:value};
      this.dtlLoading = true;
      this.$api.discInfo.discInfoQueryDiscCount(params).then(res => {
        if (res.code === 200) {
          let discCount = [];
          res.data.forEach(item => {
            if(item.supplydisc!==0){
              item.supplydisc = item.supplydisc + '%';
            }
            if(item.saledisc!==0){
              item.saledisc = item.saledisc + '%';
            }
            discCount.push(item);
          });
          this.disccountData = discCount;
          this.dtlLoading =false;
        }
      }).catch(error => {
        this.dtlLoading =false;
        return false;
      });
    },
    selectDiscCountLimit(value){
      this.dtlStatus = true;
      this.invalidLimitData= [];
      let params = {discid:value};
      this.dtlLoading = true;
      this.$api.discInfo.discInfoQueryDiscCountLimit(params).then(res => {
        if (res.code === 200) {
          let discCountLimit = [];
          res.data.forEach(item => {
            if(item.supplydisc!==0){
              item.supplydisc = item.supplydisc + '%';
            }
            if(item.saledisc!==0){
              item.saledisc = item.saledisc + '%';
            }
            discCountLimit.push(item);
          });
          this.invalidLimitData = discCountLimit;
          this.dtlLoading =false;
        }
      }).catch(error => {
        this.dtlLoading =false;
        return false;
      });
    },
    handleClick(tab,event){
      if(this.dtlIndex === 'counter'){
        this.selectCounter(this.discid);
      }else if(this.dtlIndex === 'discCount'){
        this.selectDiscCount(this.discid);
      }else if(this.dtlIndex === 'discCountLimit'){
        this.selectDiscCountLimit(this.discid);
      }
    },
    dtlDialogClose(){
		  this.counterData = [];
      this.disccountData = [];
      this.invalidLimitData= [];
      this.dtlLoading = false;
      this.dtlIndex='counter';
      this.discid=null;
		  this.dtlStatus = false;
    }
	}
}
</script>

<style>
#dtlDialogDiv  .el-dialog__header{
  border-bottom: 1px solid #ccc !important;
  background:#f5f5f5;
}
</style>
