<template>
<el-form :model="base" ref="base" label-width="100px" label-position="right" size="mini" style="width:630px;margin: 20px auto" :rules="rules">
  <el-form-item label="方案名称" prop="discname">
    <el-input v-model="base.discname"></el-input>
  </el-form-item>
  <el-form-item label="活动日期">
    <el-col :span="11">
      <el-form-item prop="begindate">
        <el-date-picker type="datetime" v-model="base.begindate" style="width:100%;" default-time="00:00:00"></el-date-picker>
      </el-form-item>
    </el-col>
    <el-col :span="2">-</el-col>
    <el-col :span="11">
      <el-form-item prop="enddate">
        <el-date-picker type="datetime" v-model="base.enddate" style="width:100%;" default-time="23:59:59"></el-date-picker>
      </el-form-item>
    </el-col>
  </el-form-item>
  <el-form-item label="促销类别" prop="discclassid" style="position: relative">
    <input v-model="base.discclassid" v-show="false">
    <el-input v-model="discclassname" :disabled="true">
      <el-button slot="append" icon="el-icon-search" @click="classNameClick"></el-button>
    </el-input>
    <el-card v-if="discClassVisible" style="position: absolute;z-index:10;width:100%;height:200px;overflow: auto">
      <div id="el-cardDiv">
      <el-tree
        :data="discClassOption"
        node-key="value"
        @node-click="handCheck"
        style="padding:0"
      >
      </el-tree>
      </div>
    </el-card>
  </el-form-item>
  <el-form-item label="会员卡类别">
    <el-checkbox-group v-model="base.cardtypeid" style="width:100%;">
      <el-checkbox-button
        v-for="(item,index) in cardTypeOption"
        :key="index"
        :label="item.value"
      >{{item.label}}</el-checkbox-button>
    </el-checkbox-group>
  </el-form-item>
  <el-form-item label="门店状态">
    <el-select v-model="base.counterflag" style="width:50%;float: left">
      <el-option value="" label="全部"></el-option>
      <!--<el-option :value="0" label="不可用"></el-option> -->
      <el-option :value="1" label="可用"></el-option>
    </el-select>
  </el-form-item>
  <el-form-item>
    <el-button type="primary" @click="ruleForm">下一步</el-button>
  </el-form-item>
</el-form>
</template>

<script>
export default {
  name: 'DiscInfoDoc',
  props:{
    discClassOption:{type: Array},
    cardTypeOption:{type: Array},
    discClassArray:{type: Array}
  },
  data () {
    var disclass = (rule,value,callback)=> {
        if(value === ''||value === null)
        {
          callback(new Error('促销类别不能为空'))
        }
        else
        {
          callback()
        }
    };
    return {
      base: {
        discname:null,
        begindate:null,
        enddate:null,
        discclassid:null,
        cardtypeid:[],
        counterflag:null,
        employeeid:null,
        companyid:null,
        serviceurl: null,
        classname: null,
        version: null,
        usestatus:1
      },
      rules:{
        discname: {required:true,message:'方案名称不能为空',trigger:'blur'},
        begindate: {required:true,type:'date',message:'开始日期不能为空',trigger: 'change'},
        enddate: {required:true,type:'date',message:'结算日期不能为空',trigger: 'change'},
        discclassid: {validator: disclass, trigger:'change'}
      },
      stepName:null,
      cardName:null,
      discclassname:null,
      discClassVisible:false,
      discClassNode:null,
      discClassNodeName:null
    }
  },
  methods:{
    docNext(){
      let parent = this.$parent;
      this.base.employeeid = Number(sessionStorage['userid']);
      this.base.companyid = Number(sessionStorage['companyid']);
      parent.docData.discinfodeflst = this.base;
      if(this.cardName.length===0)
      {
        alert("没有此方案模板");
        return false;
      }
      if(this.base.counterflag === 0 || this.base.counterflag === 1)
      {
        if(parent.hasCard("counter") === false){
          if(parent.hasCard(this.cardName) === false){
            parent.stepOption.push({card:"counter",title:'门店信息',description:'这是门店信息表'});
            parent.stepOption.push({card:this.cardName,title:this.stepName,description:'这是'+this.stepName+"方案"});
          }else{
            parent.stepOption.splice(1,0,{card:"counter",title:'门店信息',description:'这是门店信息表'});
          }
        }
        parent.stepActive = parent.stepActive + 1;
        parent.nextCard="counter";
        return;
      }
      if(parent.hasCard(this.cardName) === false){
        parent.stepOption.push({card:this.cardName,title:this.stepName,description:'这是'+this.stepName+"方案"});
      }
      parent.stepActive = parent.stepActive + 1;
      parent.nextCard=this.cardName;
    },
    ruleForm(){
      this.$refs.base.validate((valid) =>
      {
        if(valid)
        {
          this.docNext();
        }
        else
        {
          return false;
        }
      })
    },
    cascaderChange(value){
      if(value.length === 0)
      {
        let parent = this.$parent;
        parent.stepOption=[];
        parent.stepOption.push({card:'doc',title:'促销方案信息',description:'这是一张促销总单'});
        parent.stepActive=0;
        //parent.docData={};
      }
      let values = value[value.length - 1];
      this.selects(this.discClassArray, values);
    },
    selectCascader(data, value){
      if(Number(data.value) === value){
        this.stepName = data.label;
        this.cardName = data.cardName;
      }
      if(data.children){
          this.selects(data.children, value);
      }
    },
    selects(data, value){
      data.forEach(res => {
        this.selectCascader(res, value);
      })
    },
    classNameClick(){
      this.$parent.docData = {};
      this.$parent.stepOption=[];
      this.$parent.stepOption.push({card:'doc',title:'促销方案信息',description:'这是一张促销总单'});
      this.$parent.stepActive = 0;
      this.discClassVisible = true;
    },
    handCheck(data){console.log(data)
      this.base.discclassid = data.value;
      this.discclassname = data.label;
      this.base.serviceurl= data.serviceurl;
      this.base.classname= data.classname;
      this.base.version= data.version;
      this.selects(this.discClassArray, data.value);
      this.discClassVisible = false;
    }
  }
}
</script>

<style scoped>
#card{
  width:100%;
  height:100%;
}
#el-cardDiv{
  width:100%;
  height:160px;
}
</style>
