/**
 * 全局常量、方法封装模块
 * 通过原型挂载到Vue属性
 * 通过 this.Global 调用
 */

 // 后台管理系统服务器地址
     // export const baseUrl = 'http://139.196.87.48:8001'
        //export const baseUrl = 'http://172.16.2.111:8001/eprs-admin';
          //export const baseUrl = 'http://218.61.129.222:8080/eprs-admin';
          export const baseUrl = 'http://ecdfyb2b.ecdfy.com:8080/eprs-admin';
          //export const baseUrl = 'http://10.0.0.124:8001';
     //export const baseUrl = 'http://10.0.0.36:8001/eprs-admin';
  // export const baseUrl = 'http://10.0.0.46:8001'
// export const baseUrl = 'http://localhost:8001'
 // 系统数据备份还原服务器地址
// export const backupBaseUrl = 'http://139.196.87.48:8002
// export const backupBaseUrl = 'http://10.0.0.36:8001'

export default {
    baseUrl
    //backupBaseUrl
}
