/* 
 * 接口统一集成模块
 */
import * as login from './modules/login'
import * as user from './modules/user'
import * as dept from './modules/dept'
import * as role from './modules/role'
import * as menu from './modules/menu'
import * as dict from './modules/dict'
import * as config from './modules/config'
import * as log from './modules/log'
import * as loginlog from './modules/loginlog'
import * as hov from './modules/hov'
import * as drops from './modules/drops'
import * as employee from './modules/sys/employee'
import * as pfyspjbcz from './modules/financial/pfyspjbcz'
import * as ysk from './modules/financial/ysk'
import * as xssk from './modules/financial/xssk'
import * as cnskcx from './modules/financial/cnskcx'
import * as dwjbxxgl from './modules/quality/dwjbxxgl'
import * as gysgl from './modules/quality/gysgl'
import * as dqtjqsh from './modules/area/dqtjqsh'
import * as dqfz from './modules/area/dqfz'
import * as khgl from './modules/quality/khgl'
import * as hpjcsjwh from './modules/quality/hpjcsjwh'
import * as whspbhsx from './modules/replenish/whspbhsx'
import * as jxbhxxcx from './modules/replenish/jxbhxxcx'
import * as qytxl from './modules/replenish/qytxl'
import * as ywydywxh from './modules/replenish/ywydywxh'
import * as cgqdwh from './modules/replenish/cgqdwh'
import * as jhdcx from './modules/replenish/jhdcx'
import * as gysthxxwh from './modules/replenish/gysthxxwh'
import * as ywskc from './modules/replenish/ywskc'
import * as gxbhml from './modules/replenish/gxbhml'
import * as dxbhyc from './modules/replenishmentexception/dxbhyc'
import * as zbshmdzjjh from './modules/ordermanagement/zbshmdzjjh'
import * as cgddcx from './modules/ordermanagement/cgddcx'
import * as fh from './modules/ordermanagement/fh'
import * as yfdddy from './modules/ordermanagement/yfdddy'
import * as cgddgl from './modules/ordermanagement/cgddgl'
import * as price from './modules/price'
import * as ywzcx from './modules/bussiness/ywzcx'
import * as jgcx from './modules/bussiness/jgcx'
import * as bussiness from './modules/bussiness/bussiness'
import * as mdpssxtz from './modules/bussiness/mdpssxtz'
import * as ywwlcx from './modules/bussiness/ywwlcx'
import * as spjxxx from './modules/bussiness/spjxxx'
import * as wholesale from './modules/wholesale'
import * as logistics from './modules/logistics'
import * as ap from './modules/ap'
import * as returnofgoodsandreserves from './modules/returnofgoodsandreserves'
import * as replenishmentexception from './modules/replenishmentexception'
import * as onlineflow from './modules/onlineflow'
import * as area from './modules/area'
import * as discInfo from './modules/discInfo'
import * as chronicdisease from './modules/chronicdisease'

// 默认全部导出
export default {
  login,
  user,
  dept,
  role,
  menu,
  dict,
  config,
  log,
  loginlog,
  hov,
  drops,
  employee,
  pfyspjbcz,
  ysk,
  xssk,
  cnskcx,
  dwjbxxgl,
  gysgl,
  dqtjqsh,
  dqfz,
  khgl,
  hpjcsjwh,
  whspbhsx,
  jxbhxxcx,
  qytxl,
  ywydywxh,
  cgqdwh,
  jhdcx,
  gysthxxwh,
  ywskc,
  gxbhml,
  dxbhyc,
  zbshmdzjjh,
  cgddcx,
  fh,
  yfdddy,
  cgddgl,
  price,
  ywzcx,
  jgcx,
  bussiness,
  mdpssxtz,
  ywwlcx,
  spjxxx,
  wholesale,
  logistics,
  ap,
  returnofgoodsandreserves,
  replenishmentexception,
  onlineflow,
  area,
  discInfo,
  chronicdisease
}
