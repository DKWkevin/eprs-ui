import axios from '../../axios'

// 查询
export const select = (data) => {
  return axios({
    url: 'ywydywxh/select',
    method: 'post',
    data
  })
};
// 保存
export const insert = (data) => {
  return axios({
    url: 'ywydywxh/insert',
    method: 'post',
    data
  })
};
// 修改
export const update = (data) => {
  return axios({
    url: 'ywydywxh/update',
    method: 'post',
    data
  })
};
// 修改
export const del = (data) => {
  return axios({
    url: 'ywydywxh/delete',
    method: 'post',
    data
  })
};
