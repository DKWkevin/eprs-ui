import axios from '../../axios'

// 更新补货记录
export const updatebhml = (data) => {
  return axios({
    url: 'singlebutton/gxbhml',
    method: 'post',
    data
  })
};
//生成补货计划
export const updatebhjh = (data) => {
  return axios({
    url: 'singlebutton/scbhjh',
    method: 'post',
    data
  })
};
//生成补货计划
export const delpcgl = (data) => {
  return axios({
    url: 'singlebutton/pcglzfht',
    method: 'post',
    data
  })
};
//生成补货计划
export const updatepcgl = (data) => {
  return axios({
    url: 'singlebutton/pcglscht',
    method: 'post',
    data
  })
};
