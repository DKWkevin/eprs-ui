import axios from '../../axios'

// 查询总单
export const selectDoc = (data) => {
  return axios({
    url: 'jhdcx/select',
    method: 'post',
    data
  })
};
// 查询细单
export const selectDtl = (data) => {
  return axios({
    url: 'jhdcx/selectdtl',
    method: 'post',
    data
  })
};
// 查询进货明细
export const selectjhmx = (data) => {
  return axios({
    url: 'jhmxcx/select',
    method: 'post',
    data
  })
};
// 计算金额
export const selectsum = (data) => {
  return axios({
    url: 'jhmxcx/selectsumtotal',
    method: 'post',
    data
  })
};

// 查询保管账
export const selectbgz = (data) => {
  return axios({
    url: 'bgzcx/select',
    method: 'post',
    data
  })
};


// 查询采购支持
export const selectbuyid = (data) => {
  return axios({
    url: 'hpjbxx/selectcgzc',
    method: 'post',
    data
  })
};
// 查询生成订单合同
export const selectscddht = (data) => {
  return axios({
    url: 'scddht/select',
    method: 'post',
    data
  })
};
// 新增生成订单合同
export const insertddht = (data) => {
  return axios({
    url: 'scddht/insert',
    method: 'post',
    data
  })
};
// 查询仓储区域
export const selectccqy = (data) => {
  return axios({
    url: 'storeididhov/select',
    method: 'post',
    data
  })
};

