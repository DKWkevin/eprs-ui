import axios from '../../axios'

// 查询总单
export const selectDoc = (data) => {
  return axios({
    url: 'ywskc/select',
    method: 'post',
    data
  })
};
// 查询细单
export const seletdtl = (data) => {
  return axios({
    url: 'ywskc/selectwphskc',
    method: 'post',
    data
  })
};
// 保存细单
export const insertdtl = (data) => {
  return axios({
    url: 'ywskc/updatedtl',
    method: 'post',
    data
  })
};
// 删除总单
export const deldoc = (data) => {
  return axios({
    url: 'ywskc/deleteall',
    method: 'post',
    data
  })
};
// 删除细单
export const deldtl = (data) => {
  return axios({
    url: 'ywskc/deletedtl',
    method: 'post',
    data
  })
};
// 导入
export const exportInset = (data) => {
  return axios({
    url: 'ywskc/insert',
    method: 'post',
    data
  })
};
