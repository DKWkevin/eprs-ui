import axios from '../../axios'

// 查询ls
export const selectls = (data) => {
  return axios({
    url: 'whspbhsxls/select',
    method: 'post',
    data
  })
};
// 修改ls
export const insertls = (data) => {
  return axios({
    url: 'whspbhsxls/selectcompanyv',
    method: 'post',
    data
  })
};
// 查询pf
export const selectpf = (data) => {
  return axios({
    url: 'whspbhsxpf/select',
    method: 'post',
    data
  })
};
// 修改pf
export const insertpf = (data) => {
  return axios({
    url: 'whspbhsxpf/selectcompanyv',
    method: 'post',
    data
  })
};
