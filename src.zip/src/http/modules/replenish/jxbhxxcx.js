import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'jxbhxxcx/select',
    method: 'post',
    data
  })
};
/*// 查询数量
export const selectDtl = (data) => {
  return axios({
    url: 'jxbhxxcx/selectcwxx',
    method: 'post',
    data
  })
};*/
// 修改
export const insertDtl = (data) => {
  return axios({
    url: 'jxbhxxcx/update',
    method: 'post',
    data
  })
};
// 查询报错信息
export const selectError = (data) => {
  return axios({
    url: 'jxbhxxcx/selectcwxx',
    method: 'post',
    data
  })
};
// 重置数量
export const resetNumber = (data) => {
  return axios({
    url: 'jxbhxxcx/update',
    method: 'post',
    data
  })
};
//审核批次
export const commitDoc = (data) => {
  return axios({
    url: 'jxbhxxcx/pcsh',
    method: 'post',
    data
  })
};
//查询批次
export const selectpc = (data) => {
  return axios({
    url: 'jxbhpccx/select',
    method: 'post',
    data
  })
};

//查询异常记录
export const selectyc = (data) => {
  return axios({
    url: 'scbhycjl/select',
    method: 'post',
    data
  })
};

//批次hov
export const selectychov = (data) => {
  return axios({
    url: 'batchidhov/select',
    method: 'post',
    data
  })
};


