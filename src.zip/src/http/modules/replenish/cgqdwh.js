import axios from '../../axios'

// 查询
export const select = (data) => {
  return axios({
    url: 'cgqdwh/select',
    method: 'post',
    data
  })
};
// 修改
export const update = (data) => {
  return axios({
    url: 'cgqdwh/update',
    method: 'post',
    data
  })
};
