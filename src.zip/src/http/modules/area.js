import axios from '../axios'

//商品经营角色维护查询
export const selectSpjyjswh = (data) => {
  return axios({
    url: 'spjyjswh/select',
    method: 'post',
    data
  })
};
//商品经营角色维护删除
export const delSpjyjswh = (data) => {
  return axios({
    url: 'spjyjswh/delete',
    method: 'post',
    data
  })
};
//商品经营角色维护新增
export const insertSpjyjswh = (data) => {
  return axios({
    url: 'spjyjswh/insert',
    method: 'post',
    data
  })
};
//商品经营角色维护修改
export const updateSpjyjswh = (data) => {
  return axios({
    url: 'spjyjswh/update',
    method: 'post',
    data
  })
};
//商品经营角色维护导入
export const uploadSpjyjswh = (data) => {
  return axios({
    url: 'spjyjswh/importexcel',
    method: 'post',
    data
  })
};
//河北药监货品对照查询
export const selectHbyjhpdz = (data) => {
  return axios({
    url: 'hbyjhpdz/select',
    method: 'post',
    data
  })
};
//河北药监货品对照删除
export const delHbyjhpdz = (data) => {
  return axios({
    url: 'hbyjhpdz/delete',
    method: 'post',
    data
  })
};
//河北药监货品对照新增
export const insertHbyjhpdz = (data) => {
  return axios({
    url: 'hbyjhpdz/insert',
    method: 'post',
    data
  })
};
//单位区域编码对照查询
export const selectDwqybmdz = (data) => {
  return axios({
    url: 'dwqybmdz/select',
    method: 'post',
    data
  })
};
//单位区域编码对照新增
export const insertDwqybmdz = (data) => {
  return axios({
    url: 'dwqybmdz/insert',
    method: 'post',
    data
  })
};
//单位区域编码对照删除
export const delDwqybmdz = (data) => {
  return axios({
    url: 'dwqybmdz/delete',
    method: 'post',
    data
  })
};
//库存调剂地区审核总查询
export const selectDqtjqshDoc = (data) => {
  return axios({
    url: 'kctjdqsh/select',
    method: 'post',
    data
  })
};
//库存调剂地区审核查询库存
export const selectDqtjqshDocs = (data) => {
  return axios({
    url: 'spjyjswh/select',
    method: 'post',
    data
  })
};
//库存调剂地区审核查询城市
export const cityid = (data) => {
  return axios({
    url: 'cityididhov/select',
    method: 'post',
    data
  })
};
//库存调剂地区审核查询区域(暂时没用上)
export const groupid = (data) => {
  return axios({
    url: 'dqtjfz/selectdoc',
    method: 'post',
    data
  })
};


