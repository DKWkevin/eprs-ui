import axios from '../axios'

// 查询
export const selecttj = (data) => {
  return axios({
    url: 'tjjlcx/select',
    method: 'post',
    data
  })
};
// 查询
export const selectJgtz = (data) => {
  return axios({
    url: 'tgtz/select',
    method: 'post',
    data
  })
};
// 修改
export const updateAll1 = (data) => {
  return axios({
    url: 'tjjlcx/select',
    method: 'post',
    data
  })
};
// 修改
export const updateAll2 = (data) => {
  return axios({
    url: 'tjjlcx/select',
    method: 'post',
    data
  })
};
// 修改
export const updateAll3 = (data) => {
  return axios({
    url: 'tjjlcx/select',
    method: 'post',
    data
  })
};
