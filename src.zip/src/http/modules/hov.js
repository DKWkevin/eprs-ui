import axios from '../axios'


// 保存
export const query = (url,data) => {
  return axios({
    url,
    method: 'post',
    data
  })
};

// ddl
export const sysddl = (data) => {
  return axios({
    url:'sys-ddl/select',
    method: 'post',
    data
  })
};
// counteridhov/select  门店
// customidhov/select  单位
// employeeididhov/select  人员
// outbankidhov/select  银行
// companyidhov/selectcompanyid  公司
// goodsidhov/select  货品
// contactinfoidhov/select  联系方式
