import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'dxbhyc/select',
    //url: 'test/select',
    method: 'post',
    data
  })
};
// 查询细单
export const selectDtl = (data) => {
  return axios({
    url: 'dxbhyc/selectdtl',
    method: 'post',
    data
  })
};
