import axios from '../../axios'

// 总单查询
export const select = (data) => {
  return axios({
    url: 'cdfk/selectapbapaybind',
    method: 'post',
    data
  })
};
// 细单查询
export const selectdtl = (data) => {
  return axios({
    url: 'cdfk/selectapbabind',
    method: 'post',
    data
  })
};
// 付款单查询
export const selectLeft = (data) => {
  return axios({
    url: 'cdfk/selectapsupayment',
    method: 'post',
    data
  })
};
// 票据查询
export const selectRight = (data) => {
  return axios({
    url: 'cdfk/selectapbabinddetail',
    method: 'post',
    data
  })
};
// 银行查询
export const selectBank = (data) => {
  return axios({
    url: 'bankidhov/select',
    method: 'post',
    data
  })
};
// 细单保存
export const insert = (data) => {
  return axios({
    url: 'cdfk/saveall',
    method: 'post',
    data
  })
};
