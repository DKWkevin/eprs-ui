import axios from '../../axios'

// 查询
export const select = (data) => {
  return axios({
    url: 'xssk/selectArSaSettleDoc',
    method: 'post',
    data
  })
}
// 查询
export const selectdtl = (data) => {
  return axios({
    url: 'xssk/selectArSaSettleDtl',
    method: 'post',
    data
  })
}
// 确认
export const insert = (data) => {
  return axios({
    url: 'xssk/insert',
    method: 'post',
      data
  })
}
