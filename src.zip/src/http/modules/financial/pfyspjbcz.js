import axios from '../../axios'

// 查询
export const select = (data) => {
  return axios({
    url: 'pfyspjbcz/select',
    method: 'post',
    data
  })
};
// 保存
export const add = (data) => {
  return axios({
    url: 'pfyspjbcz/addCashier',
    method: 'post',
    data
  })
};
// 编辑
export const update = (data) => {
  return axios({
    url: 'pfyspjbcz/updateCashier',
    method: 'post',
    data
  })
};
// 确认
export const comfirm = (data) => {
  return axios({
    url: 'pfyspjbcz/updateCashier',
    method: 'post',
    data
  })
};
// 删除
export const dtldelete = (data) => {
  return axios({
    url: 'pfyspjbcz/updateCashier',
    method: 'post',
    data
  })
};
// 导入
export const addexcelCashier = (data) => {
  return axios({
    url: 'pfyspjbcz/addexcelCashier',
    method: 'post',
    data
  })
};

