import axios from '../../axios'

// 总单查询
export const select = (data) => {
  return axios({
    url: 'cnskcx/selectdoc',
    method: 'post',
    data
  })
};
// 细单查询
export const selectdtl = (data) => {
  return axios({
    url: 'cnskcx/selectdtl',
    method: 'post',
    data
  })
};
// cbs查询
export const selectcbs = (data) => {
  return axios({
    url: 'cnskcx/selectbankdtl',
    method: 'post',
    data
  })
};
// cbs提交
export const updatecbs = (data) => {
  return axios({
    url: 'cnskcx/updateusestatus',
    method: 'post',
    data
  })
};
// 细单提交
export const updatedtl = (data) => {
  return axios({
    url: 'cnskcx/updatearrprecdtl',
    method: 'post',
    data
  })
};
// 总单确认
export const comfirmDoc = (data) => {
  return axios({
    url: 'cnskcx/confirm',
    method: 'post',
    data
  })
};
// 总单作废
export const deleteDoc = (data) => {
  return axios({
    url: 'cnskcx/invalid',
    method: 'post',
    data
  })
};
