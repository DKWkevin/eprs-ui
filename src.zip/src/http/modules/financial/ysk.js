import axios from '../../axios'

// 查询
export const select = (data) => {
  return axios({
    url: 'ysk/select',
    method: 'post',
    data
  })
}
// 保存
export const save = (data) => {
    return axios({
      url: 'ysk/insert',
      method: 'post',
      data
    })
}
