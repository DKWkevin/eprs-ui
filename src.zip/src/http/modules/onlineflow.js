import axios from '../axios'
//收费标准定义查询
export const selectSfbzdy = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//收费标准定义新增
export const insertSfbzdy = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//收费标准定义修改
export const updateSfbzdy = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//收费标准定义删除
export const delSfbzdy = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//收费标准定义停用
export const stopSfbzdy = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//收费标准定义恢复
export const recoverySfbzdy = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费新增
export const insertLlgyskhxf = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费修改
export const updateLlgyskhxf = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费查询
export const selectLlgyskhxf = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费删除
export const delLlgyskhxf = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费停用
export const stopLlgyskhxf = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费恢复
export const recoveryLlgyskhxf = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费续费查询
export const selectLlgyskhxfXufei = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费续费
export const llgyskhxfxufei = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费全品种续费
export const llgyskhxfAllrenew = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费密码重置
export const llgyskhxfReset = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费批量修改工业
export const llgyskhxfGy = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商开户续费批量修改商业
export const llgyskhxfSy = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商货品维护查询
export const selectLlgyhpwh = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商货品维护新增
export const insertLlgyshpwh = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商货品维护停用
export const stopLlgyshpwh = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商货品维护恢复
export const recoveryLlgyshpwh = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};
//辽连供应商货品维护续费查询
export const selectLlgyhpwhfXufei = (data) =>{
  return axios({
    url:'',
    method:'POST',
    data
  })
};

