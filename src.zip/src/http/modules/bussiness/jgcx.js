import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'jgcx/select',
    method: 'post',
    data
  })
};
// 查询上月调拨量
export const selectDtl = (data) => {
  return axios({
    url: 'jgcx/selectgdqlsjg',
    method: 'post',
    data
  })
};

