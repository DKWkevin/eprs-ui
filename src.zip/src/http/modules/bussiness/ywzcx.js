import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'ywzcx/select',
    method: 'post',
    data
  })
};
// 查询上月调拨量
export const selectSydbl = (data) => {
  return axios({
    url: 'ywzcx/selectsydb',
    method: 'post',
    data
  })
};
//查询上月实销
export const selectSysx = (data) => {
  return axios({
    url: 'ywzcx/selectsysx',
    method: 'post',
    data
  })
};
//查询前期实销
export const selectQqsx = (data) => {
  return axios({
    url: 'ywzcx/selectqqsx',
    method: 'post',
    data
  })
};
//查询地区库存
export const selectDqkc = (data) => {
  return axios({
    url: 'ywzcx/selectdqkc',
    method: 'post',
    data
  })
};
//查询联系人
export const selectLxr = (data) => {
  return axios({
    url: 'ywzcx/selectlxr',
    method: 'post',
    data
  })
};
//查询委托人
export const selectSqwtr = (data) => {
  return axios({
    url: 'ywzcx/selectsqwtr',
    method: 'post',
    data
  })
};
//查询进货明细
export const selectJhmx = (data) => {
  return axios({
    url: 'ywzcx/selectjhmx',
    method: 'post',
    data
  })
};
//查询不可销数
export const selectBkxs = (data) => {
  return axios({
    url: 'ywzcx/selectbkxs',
    method: 'post',
    data
  })
};
//查询账面数量
export const selectZmsl = (data) => {
  return axios({
    url: 'ywzcx/selectzmsl',
    method: 'post',
    data
  })
};
//查询出库未提
export const selectCkwt = (data) => {
  return axios({
    url: 'ywzcx/selectckwt',
    method: 'post',
    data
  })
};
