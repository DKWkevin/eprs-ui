import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'ywwlzcx/select',
    method: 'post',
    data
  })
};
// 修改天数
export const selectDtl = (data) => {
  return axios({
    url: 'ywwlzcx/selectdtl',
    method: 'post',
    data
  })
};
