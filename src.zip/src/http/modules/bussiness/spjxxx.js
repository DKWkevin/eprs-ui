import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'ddyc/select',
    method: 'post',
    data
  })
};
// 保存
export const insert = (data) => {
  return axios({
    url: 'ddyc/selectdtl',
    method: 'post',
    data
  })
};
// 保存
export const dervice = (data) => {
  return axios({
    url: 'ddyc/selectdtl',
    method: 'post',
    data
  })
};
