import axios from '../../axios'

// 采购渠道查询
export const selectCgqd = (data) => {
  return axios({
    url: 'cgqdcx/select',
    method: 'post',
    data
  })
};
// 供应商信息查询
export const selectGysxx = (data) => {
  return axios({
    url: 'gysxxcx/select',
    method: 'post',
    data
  })
};
// 采购渠道调整查询
export const selectCgqdtz = (data) => {
  return axios({
    url: 'cgqdtzcx/select',
    method: 'post',
    data
  })
};
// 采购渠道调整查询
export const selectSpxs = (data) => {
  return axios({
    url: 'spxscx/select',
    method: 'post',
    data
  })
};
