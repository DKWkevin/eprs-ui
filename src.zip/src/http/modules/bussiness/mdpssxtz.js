import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'mdpssxtz/select',
    method: 'post',
    data
  })
};
// 修改天数
export const updateDays = (data) => {
  return axios({
    url: 'mdpssxtz/update',
    method: 'post',
    data
  })
};
