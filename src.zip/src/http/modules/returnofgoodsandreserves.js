import aixos from '../axios'
//查询储备品种维护
export const selectCbpzwh = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//新增储备品种维护总单
export const insertCbpzwhDoc = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//修改储备品种维护总单
export const updateCbpzwhDoc = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//删除储备品种维护总单
export const delCbpzwhDoc = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//查询储备品种维护细单
export const selectCbpzwhDtl = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//新增储备品种维护细单
export const insertCbpzwhDtl = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//修改储备品种维护细单
export const updateCbpzwhDtl = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//删除储备品种维护细单
export const delCbpzwhDtl = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//下载储备品种维护（带批号）
export const downloadCbpzwh = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//退货通知单
export const selectThtzd = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//退货通知单审批
export const thtzdSp = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//退货通知单作废
export const thtzdDelete = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//退货通知单批量作废
export const thtzdDeleteAll = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//退货通知单查看细单
export const selectThtzdDtl = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//退货通知单保存细单
export const thtzdInsert = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//退货通知单导入
export const addThtzdExcelCashier = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//进货退货通知现货位库存
export const selectJhthtzRemqty = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
//进货退货通知保存
export const insertJhthtzAll = (data) =>{
  return aixos({
    url:'',
    method:'post',
    data
  })
};
