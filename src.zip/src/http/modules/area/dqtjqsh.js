import axios from '../../axios'


// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'kctjdqsh/select',
    method: 'post',
    data
  })
};
// 新增
export const saveDoc = (data) => {
  return axios({
    url: 'kctjdqsh/insert',
    method: 'post',
    data
  })
};
// 修改配送状态
export const updatePszt = (data) => {
  return axios({
    url: 'kctjdqsh/update',
    method: 'post',
    data
  })
};
// 批量修改配送状态
export const updatemultiple = (data) => {
  return axios({
    url: 'kctjdqsh/updatemultiple',
    method: 'post',
    data
  })
};
// 修改调剂标志数量
export const updateTjbzsl = (data) => {
  return axios({
    url: 'kctjdqsh/update',
    method: 'post',
    data
  })
};
// 查询
export const selectExecl = (data) => {
  return axios({
    url: 'kctjdqsh/psdqkctjselect',
    method: 'post',
    data
  })
};
// 导入
export const saveExecl = (data) => {
  return axios({
    url: 'kctjdqsh/psdqkctjinsert',
    method: 'post',
    data
  })
};
// 保存
export const saveStatus = (data) => {
  return axios({
    url: 'kctjdqsh/pskctjgoodsupdate',
    method: 'post',
    data
  })
};
//查询城市
export const cityid = (data) => {
  return axios({
    url: 'cityididhov/select',
    method: 'post',
    data
  })
};
//查询区域
export const groupid = (data) => {
  return axios({
    url: 'dqtjfz/selectdoc',
    method: 'post',
    data
  })
};
// 删除调剂标志数量
export const delExecl = (data) => {
  return axios({
    url: 'kctjdqsh/deletepsdqkctjgoodsseparate',
    method: 'post',
    data
  })
};
// 删除临时调剂标志数量
export const delTemp = (data) => {
  return axios({
    url: 'kctjdqsh/deletepsdqkctjgoodsseparate',
    method: 'post',
    data
  })
};
// 单条保存数据
export const insertSingle = (data) => {
  return axios({
    url: 'kctjdqsh/insertpsdqkctjgoodsseparate',
    method: 'post',
    data
  })
};
export const judgeremqty = (data) => {
  return axios({
    url: 'kctjdqsh/judgeremqty',
    method: 'post',
    data
  })
};
export const dqtjdqshMdzxbtp = (data) => {
  return axios({
    url: 'kctjdqsh/counterImplement',
    method: 'post',
    data
  })
};
