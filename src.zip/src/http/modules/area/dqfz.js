import axios from '../../axios'
// 查询
export const selectCity = (data) => {
  return axios({
    url: 'dqtjfz/selectcityid',
    method: 'post',
    data
  })
};
export const selectCounter = (data) => {
  return axios({
    url: 'dqtjfz/selectcounterid',
    method: 'post',
    data
  })
};
export const selectDtl = (data) => {
  return axios({
    url: 'dqtjfz/selectdtl',
    method: 'post',
    data
  })
};
export const insertDoc = (data) => {
  return axios({
    url: 'dqtjfz/insertdoc',
    method: 'post',
    data
  })
};
export const insertDtl = (data) => {
  return axios({
    url: 'dqtjfz/insertdtl',
    method: 'post',
    data
  })
};
export const delDoc = (data) => {
  return axios({
    url: 'dqtjfz/deletedoc',
    method: 'post',
    data
  })
};
export const delDtl = (data) => {
  return axios({
    url: 'dqtjfz/deletedtl',
    method: 'post',
    data
  })
};
