import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'dwjbxxgl/selectcompanyv',
    method: 'post',
    data
  })
};
// 查询明细
export const selectDtl = (data) => {
  return axios({
    url: 'dwjbxxgl/selectgsprzfw',
    method: 'post',
    data
  })
};
// 删除范围
export const selectDtlDel = (data) => {
  return axios({
    url: 'dwjbxxgl/deletegsprzfw',
    method: 'post',
    data
  })
};
// 保存基本信息
export const saveBase = (data) => {
  return axios({
    url: 'dwjbxxgl/pubcompanyinsert',
    method: 'post',
    data
  })
};
// 修改基本信息
export const updateBase = (data) => {
  return axios({
    url: 'dwjbxxgl/pubcompanyupdate',
    method: 'post',
    data
  })
};
// 修改基本信息
export const selectlxr = (data) => {
  return axios({
    url: 'dwjbxxgl/selectpubcompanycontactinfo',
    method: 'post',
    data
  })
};
// 保存联系人信息
export const savelxr = (data) => {
  return axios({
    url: 'dwjbxxgl/insertpubcompanycontactinfo',
    method: 'post',
    data
  })
};
// 修改联系人信息
export const updatelxr = (data) => {
  return axios({
    url: 'dwjbxxgl/updatepubcompanycontactinfo',
    method: 'post',
    data
  })
};
// 删除联系人信息
export const deletelxr = (data) => {
  return axios({
    url: 'dwjbxxgl/deletepubcompanycontactinfo',
    method: 'post',
    data
  })
};
// 查询固定业务
export const selectgdyw = (data) => {
  return axios({
    url: 'dwjbxxgl/selectpubcompanyfixcontactinfo',
    method: 'post',
    data
  })
};
// 保存固定业务
export const savegdyw = (data) => {
  return axios({
    url: 'dwjbxxgl/insertpubcompanyfixcontactinfo',
    method: 'post',
    data
  })
};
// 删除固定业务
export const deletegdyw = (data) => {
  return axios({
    url: 'dwjbxxgl/deletepubcompanyfixcontactinfo',
    method: 'post',
    data
  })
};
// 查询固定业务
export const selectcw = (data) => {
  return axios({
    url: 'dwjbxxgl/selectpubcompanyfinanceinfo',
    method: 'post',
    data
  })
};
// 新增固定业务
export const savecw = (data) => {
  return axios({
    url: 'dwjbxxgl/insertpubcompanyfinanceinfo',
    method: 'post',
    data
  })
};
// 修改固定业务
export const updatecw = (data) => {
  return axios({
    url: 'dwjbxxgl/updatepubcompanyfinanceinfo',
    method: 'post',
    data
  })
};

