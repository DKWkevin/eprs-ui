import axios from '../../axios'
// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'hpjbxx/select',
    method: 'post',
    data
  })
};
//新增基本信息
export const insertBase = (data) => {
  return axios({
    url: 'hpjbxx/insertjbxx',
    method: 'post',
    data
  })
};
//修改基本信息
export const updateBase = (data) => {
  return axios({
    url: 'hpjbxx/updatejbxx',
    method: 'post',
    data
  })
};
//查询包装信息
export const selectBzxx = (data) => {
  return axios({
    url: 'hpjbxx/selectbzxx',
    method: 'post',
    data
  })
};
//新增包装信息
export const insertBzxx = (data) => {
  return axios({
    url: 'hpjbxx/insertbzxx',
    method: 'post',
    data
  })
};
//修改包装信息
export const updateBzxx = (data) => {
  return axios({
    url: 'hpjbxx/updatebzxx',
    method: 'post',
    data
  })
};
//删除包装信息
export const delBzxx = (data) => {
  return axios({
    url: 'hpjbxx/deletebzxx',
    method: 'post',
    data
  })
};
// 查询质量信息
export const selectZlxx = (data) => {
  return axios({
    url: 'hpjbxx/selectzlxx',
    method: 'post',
    data
  })
};
// 保存质量信息
export const insertZlxx = (data) => {
  return axios({
    url: 'hpjbxx/insertorupdatezlxx',
    method: 'post',
    data
  })
};
// 保存采购经理
export const insertCgjl = (data) => {
  return axios({
    url: 'hpjbxx/insertorupdatecgjl',
    method: 'post',
    data
  })
};
// 查询采购经理
export const selectCgjl = (data) => {
  return axios({
    url: 'hpjbxx/selectcgjl',
    method: 'post',
    data
  })
};
//  查询组合品细单
export const selectZhp = (data) => {
  return axios({
    url: 'hpjbxx/selectzhp',
    method: 'post',
    data
  })
};
// 保存组合品细单
export const insertZhp = (data) => {
  return axios({
    url: 'hpjbxx/insertzhp',
    method: 'post',
    data
  })
};
// 修改组合品细单
export const updateZhp = (data) => {
  return axios({
    url: 'hpjbxx/updatezhp',
    method: 'post',
    data
  })
};
//查询采购分组
export const selectCgfz = (data) => {
  return axios({
    url: 'hpjbxx/selectcgfz',
    method: 'post',
    data
  })
};
export const selectssflbm = (data) => {
  return axios({
    url: 'hpjbxx/selectssflbm',
    method: 'post',
    data
  })
};
