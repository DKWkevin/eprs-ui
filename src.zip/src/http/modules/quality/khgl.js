import axios from '../../axios'

export const selectDoc = (data) =>{
  return axios({
    url:'khgl/select',
    method:'Post',
    data
  })
};
export const save = (data) =>{
  return axios({
    url:'khgl/add',
    method:'Post',
    data
  })
};
export const update = (data) =>{
  return axios({
    url:'khgl/update',
    method:'Post',
    data
  })
};
