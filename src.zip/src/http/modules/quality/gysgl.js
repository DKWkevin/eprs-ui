import axios from '../../axios'

// 查询
export const select = (data) => {
  return axios({
    url: 'gysgl/select',
    method: 'post',
    data
  })
};
// 查询
export const save = (data) => {
  return axios({
    url: 'gysgl/add',
    method: 'post',
    data
  })
};
// 查询
export const update = (data) => {
  return axios({
    url: 'gysgl/update',
    method: 'post',
    data
  })
};
