import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'yfdddy/select',
    method: 'post',
    data
  })
};
// 查询细单
export const selectDtl = (data) => {
  return axios({
    url: 'yfdddy/selectdtl',
    method: 'post',
    data
  })
};
// 查询细单
export const selectPrint = (data) => {
  return axios({
    url: 'yfdddy/print',
    method: 'post',
    data
  })
};
// 查询细单
export const printTotal = (data) => {
  return axios({
    url: 'yfdddy/printtotal',
    method: 'post',
    data
  })
};
