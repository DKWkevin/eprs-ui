import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'cgqdwh/select',
    method: 'post',
    data
  })
};
// 作废
export const deldoc = (data) => {
  return axios({
    url: 'cgqdwh/update',
    method: 'post',
    data
  })
};
// 批量作废
export const delAll = (data) => {
  return axios({
    url: 'cgqdwh/update',
    method: 'post',
    data
  })
};
