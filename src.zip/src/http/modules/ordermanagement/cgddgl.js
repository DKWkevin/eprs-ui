import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'cgddgl/select',
    method: 'post',
    data
  })
};
// 查询订单
export const selectGoods = (data) => {
  return axios({
    url: 'cgddgl/selectgoods',
    method: 'post',
    data
  })
};
// 生成采购订单
export const insertGoods = (data) => {
  return axios({
    url: 'cgddgl/insert',
    method: 'post',
    data
  })
};
// 查询安全库存
export const selectUpdateKc = (data) => {
  return axios({
    url: 'cgddgl/selectgoods',
    method: 'post',
    data
  })
};
// 修改安全库存
export const updatekc = (data) => {
  return axios({
    url: 'cgddgl/updateaqkc',
    method: 'post',
    data
  })
};
// 通讯录查询
export const selectlxr = (data) => {
  return axios({
    url: 'cgddgl/selectlxr',
    method: 'post',
    data
  })
};
