import axios from '../../axios'

// 查询
export const select = (data) => {
  return axios({
    url: 'cgqdwh/select',
    method: 'post',
    data
  })
};
// 作废
export const deleteDtl = (data) => {
  return axios({
    url: 'cgqdwh/update',
    method: 'post',
    data
  })
};
// 查询采购订单明细查询
export const selectDoc = (data) => {
  return axios({
    url: 'cgddmxcx/select',
    method: 'post',
    data
  })
};
