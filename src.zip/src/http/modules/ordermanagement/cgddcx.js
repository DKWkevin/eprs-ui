import axios from '../../axios'

// 查询
export const selectDoc = (data) => {
  return axios({
    url: 'cgddcxzf/select',
    method: 'post',
    data
  })
};
// 查询细单
export const selectDtl = (data) => {
  return axios({
    url: 'cgddcxzf/selectdtl',
    method: 'post',
    data
  })
};
// 作废总单
export const selectZfDoc = (data) => {
  return axios({
    url: 'cgddcxzf/invalid',
    method: 'post',
    data
  })
};
// 终止总单
export const selectZzDoc = (data) => {
  return axios({
    url: 'cgddcxzf/termination',
    method: 'post',
    data
  })
};
// 作废细单
export const selectZfDtl = (data) => {
  return axios({
    url: 'cgddcxzf/invaliddtl',
    method: 'post',
    data
  })
};
// 终止细单
export const selectZzDtl = (data) => {
  return axios({
    url: 'cgddcxzf/terminationdtl',
    method: 'post',
    data
  })
};
// 保存细单
export const insertDtl = (data) => {
  return axios({
    url: 'cgddcxzf/updatedtl',
    method: 'post',
    data
  })
};
